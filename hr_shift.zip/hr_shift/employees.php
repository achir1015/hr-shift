<?php
require_once __DIR__ . '/config.php';
$page_title = '員工管理';
$active     = 'employees';

$pdo    = getDB();
$cid    = currentCompanyId();

// ── 一般員工跳到個人資料頁，不允許進入員工管理 ───────────────
if (!isManager()) {
    header('Location: my_profile.php');
    exit;
}

$action = $_GET['action'] ?? 'list';

// ── POST 處理 ─────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'] ?? '';

    if ($type === 'save') {
        $id       = (int)($_POST['emp_id'] ?? 0);
        $dept_id  = (int)$_POST['dept_id'];
        $name     = trim($_POST['real_name']);
        $idcard   = trim($_POST['id_card']);
        $phone    = trim($_POST['phone']);
        $email    = trim($_POST['email']);
        $addr     = trim($_POST['address']);
        $wtype    = $_POST['work_type'];
        $role     = $_POST['account_role'];
        $hourly   = $_POST['hourly_wage']    ?: null;
        $monthly  = $_POST['monthly_salary'] ?: null;
        $newpass  = trim($_POST['emp_password'] ?? '');

        if ($id) {
            // 有填新密碼才更新密碼
            if ($newpass !== '') {
                $st = $pdo->prepare(
                    'UPDATE Employee_Tab SET dept_id=?,real_name=?,id_card=?,phone=?,email=?,
                     address=?,work_type=?,account_role=?,hourly_wage=?,monthly_salary=?,emp_password=?
                     WHERE emp_id=? AND company_id=?'
                );
                $st->execute([$dept_id,$name,$idcard,$phone,$email,$addr,$wtype,$role,$hourly,$monthly,md5($newpass),$id,$cid]);
            } else {
                $st = $pdo->prepare(
                    'UPDATE Employee_Tab SET dept_id=?,real_name=?,id_card=?,phone=?,email=?,
                     address=?,work_type=?,account_role=?,hourly_wage=?,monthly_salary=?
                     WHERE emp_id=? AND company_id=?'
                );
                $st->execute([$dept_id,$name,$idcard,$phone,$email,$addr,$wtype,$role,$hourly,$monthly,$id,$cid]);
            }
            flash('員工資料已更新');
        } else {
            $st = $pdo->prepare(
                'INSERT INTO Employee_Tab
                 (company_id,dept_id,real_name,id_card,phone,email,address,work_type,account_role,hourly_wage,monthly_salary,emp_password)
                 VALUES(?,?,?,?,?,?,?,?,?,?,?,?)'
            );
            $pass_hash = $newpass !== '' ? md5($newpass) : null;
            $st->execute([$cid,$dept_id,$name,$idcard,$phone,$email,$addr,$wtype,$role,$hourly,$monthly,$pass_hash]);
            flash('員工已新增');
        }
        header('Location: employees.php');
        exit;
    }

    if ($type === 'delete') {
        $id = (int)$_POST['emp_id'];
        $pdo->prepare('DELETE FROM Employee_Tab WHERE emp_id=? AND company_id=?')->execute([$id,$cid]);
        flash('員工已刪除', 'error');
        header('Location: employees.php');
        exit;
    }
}

// ── 資料讀取 ─────────────────────────────────────────────────
$search = trim($_GET['q'] ?? '');
$depts  = $pdo->prepare('SELECT * FROM Department_Tab WHERE company_id=? ORDER BY dept_name');
$depts->execute([$cid]);
$depts  = $depts->fetchAll();

$sql = 'SELECT e.*, d.dept_name FROM Employee_Tab e
        LEFT JOIN Department_Tab d ON e.dept_id=d.dept_id
        WHERE e.company_id=?';
$params = [$cid];
if ($search) {
    $sql .= ' AND (e.real_name LIKE ? OR e.phone LIKE ? OR e.email LIKE ?)';
    $params[] = "%$search%";
    $params[] = "%$search%";
    $params[] = "%$search%";
}
$sql .= ' ORDER BY e.emp_id';
$st = $pdo->prepare($sql);
$st->execute($params);
$employees = $st->fetchAll();

// 編輯用
$editEmp = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $st = $pdo->prepare('SELECT * FROM Employee_Tab WHERE emp_id=? AND company_id=?');
    $st->execute([(int)$_GET['id'], $cid]);
    $editEmp = $st->fetch();
}
$showForm = ($action === 'add' || $editEmp);

require_once '_nav.php';
?>

<div class="page-header">
  <div class="page-title">員工管理<small>員工基本資料與帳號權限</small></div>
  <a href="?action=add" class="btn btn-primary">👤 新增員工</a>
</div>

<!-- 新增 / 編輯表單 -->
<?php if ($showForm): ?>
<div class="card mb-2">
  <div class="card-header">
    <div class="card-title"><?= $editEmp ? '✏️ 編輯員工' : '➕ 新增員工' ?></div>
  </div>
  <div class="card-body">
    <form method="POST">
      <input type="hidden" name="type" value="save">
      <?php if ($editEmp): ?>
        <input type="hidden" name="emp_id" value="<?= $editEmp['emp_id'] ?>">
      <?php endif; ?>
      <div class="form-grid">
        <div class="form-group">
          <label class="form-label">真實姓名 <span class="req">*</span></label>
          <input type="text" name="real_name" class="form-control"
                 value="<?= e($editEmp['real_name'] ?? '') ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">身分證字號</label>
          <input type="text" name="id_card" class="form-control"
                 value="<?= e($editEmp['id_card'] ?? '') ?>" maxlength="10">
        </div>
        <div class="form-group">
          <label class="form-label">手機號碼</label>
          <input type="tel" name="phone" class="form-control"
                 value="<?= e($editEmp['phone'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label class="form-label">電子信箱</label>
          <input type="email" name="email" class="form-control"
                 value="<?= e($editEmp['email'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label class="form-label">所屬部門</label>
          <select name="dept_id" class="form-control">
            <?php foreach ($depts as $d): ?>
              <option value="<?= $d['dept_id'] ?>"
                <?= (($editEmp['dept_id'] ?? '') == $d['dept_id']) ? 'selected' : '' ?>>
                <?= e($d['dept_name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">工時型態</label>
          <select name="work_type" class="form-control">
            <?php foreach (['正常工時','變形工時','兼職'] as $wt): ?>
              <option value="<?= $wt ?>"
                <?= (($editEmp['work_type'] ?? '正常工時') === $wt) ? 'selected' : '' ?>>
                <?= $wt ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">帳號權限</label>
          <select name="account_role" class="form-control">
            <?php foreach (['一般員工','管理者','外部帳號'] as $r): ?>
              <option value="<?= $r ?>"
                <?= (($editEmp['account_role'] ?? '一般員工') === $r) ? 'selected' : '' ?>>
                <?= $r ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
        <div class="form-group">
          <label class="form-label">時薪（元）</label>
          <input type="number" name="hourly_wage" class="form-control" step="0.01"
                 value="<?= e($editEmp['hourly_wage'] ?? '') ?>" placeholder="兼職用">
        </div>
        <div class="form-group">
          <label class="form-label">月薪（元）</label>
          <input type="number" name="monthly_salary" class="form-control" step="0.01"
                 value="<?= e($editEmp['monthly_salary'] ?? '') ?>" placeholder="正職用">
        </div>
        <div class="form-group full">
          <label class="form-label">住址（在家打卡基準）</label>
          <input type="text" name="address" class="form-control"
                 value="<?= e($editEmp['address'] ?? '') ?>" placeholder="台北市信義區...">
        </div>
        <div class="form-group">
          <label class="form-label">
            登入密碼
            <?php if ($editEmp): ?>
              <span class="text-muted" style="font-weight:400;">（留空則不修改）</span>
            <?php else: ?>
              <span class="req">*</span>
            <?php endif; ?>
          </label>
          <input type="password" name="emp_password" class="form-control"
                 placeholder="員工登入密碼（手機或Email登入用）"
                 autocomplete="new-password">
        </div>
      </div>
      <div class="form-actions mt-2">
        <button type="submit" class="btn btn-primary">💾 儲存</button>
        <a href="employees.php" class="btn btn-secondary">取消</a>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<!-- 搜尋 -->
<form method="GET" class="search-bar">
  <input type="text" name="q" class="form-control" placeholder="🔍 搜尋姓名 / 電話 / 信箱…"
         value="<?= e($search) ?>">
  <button type="submit" class="btn btn-secondary">搜尋</button>
  <?php if ($search): ?>
    <a href="employees.php" class="btn btn-secondary">清除</a>
  <?php endif; ?>
</form>

<!-- 員工清單 -->
<div class="card">
  <div class="card-header">
    <div class="card-title">👥 員工列表</div>
    <span class="badge badge-cyan"><?= count($employees) ?> 人</span>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>姓名</th>
          <th>部門</th>
          <th>工時型態</th>
          <th>帳號權限</th>
          <th>手機</th>
          <th>月薪 / 時薪</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($employees): ?>
          <?php foreach ($employees as $e): ?>
            <tr>
              <td class="text-muted"><?= $e['emp_id'] ?></td>
              <td><strong><?= e($e['real_name']) ?></strong></td>
              <td><?= e($e['dept_name'] ?? '—') ?></td>
              <td>
                <?php
                  $wbadge = ['正常工時'=>'badge-cyan','變形工時'=>'badge-amber','兼職'=>'badge-green'];
                ?>
                <span class="badge <?= $wbadge[$e['work_type']] ?? 'badge-gray' ?>">
                  <?= e($e['work_type']) ?>
                </span>
              </td>
              <td>
                <?php
                  $rbadge = ['管理者'=>'badge-navy','一般員工'=>'badge-gray','外部帳號'=>'badge-amber'];
                ?>
                <span class="badge <?= $rbadge[$e['account_role']] ?? 'badge-gray' ?>">
                  <?= e($e['account_role']) ?>
                </span>
              </td>
              <td><?= e($e['phone'] ?? '—') ?></td>
              <td class="text-sm">
                <?php if ($e['monthly_salary']): ?>
                  月薪 $<?= number_format($e['monthly_salary']) ?>
                <?php elseif ($e['hourly_wage']): ?>
                  時薪 $<?= number_format($e['hourly_wage'],0) ?>
                <?php else: ?>—<?php endif; ?>
              </td>
              <td>
                <div class="td-actions">
                  <a href="?action=edit&id=<?= $e['emp_id'] ?>" class="btn btn-sm btn-secondary">✏️ 編輯</a>
                  <form method="POST" id="de<?= $e['emp_id'] ?>">
                    <input type="hidden" name="type" value="delete">
                    <input type="hidden" name="emp_id" value="<?= $e['emp_id'] ?>">
                    <button type="button" class="btn btn-sm btn-danger"
                      onclick="confirmDelete('確定刪除員工「<?= e($e['real_name']) ?>」嗎？','de<?= $e['emp_id'] ?>')">🗑️</button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr>
            <td colspan="8">
              <div class="empty-state">
                <div class="icon">👤</div>
                <p>尚無員工資料，<a href="?action=add">立即新增</a></p>
              </div>
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once '_footer.php'; ?>
