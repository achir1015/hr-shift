<?php
require_once __DIR__ . '/config.php';
$page_title = '公司 / 部門管理';
$active     = 'companies';
$pdo = getDB();
requireManager();

$pdo = getDB();
$action = $_GET['action'] ?? 'list';

// ── POST 處理 ─────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'] ?? '';

    // 儲存公司
    if ($type === 'save_company') {
        $id   = (int)($_POST['company_id'] ?? 0);
        $name = trim($_POST['company_name']);
        $vat  = trim($_POST['vat_number']) ?: null;
        $biz  = trim($_POST['business_hours']) ?: null;

        if ($id) {
            $st = $pdo->prepare('UPDATE Company_Tab SET company_name=?,vat_number=?,business_hours=? WHERE company_id=?');
            $st->execute([$name, $vat, $biz, $id]);
            flash('公司資料已更新');
        } else {
            $st = $pdo->prepare('INSERT INTO Company_Tab(company_name,vat_number,business_hours,account_mgr_id) VALUES(?,?,?,1)');
            $st->execute([$name, $vat, $biz]);
            flash('公司已新增');
        }
        header('Location: companies.php');
        exit;
    }

    // 儲存部門
    if ($type === 'save_dept') {
        $id   = (int)($_POST['dept_id'] ?? 0);
        $cid  = (int)$_POST['company_id'];
        $name = trim($_POST['dept_name']);

        if ($id) {
            $st = $pdo->prepare('UPDATE Department_Tab SET dept_name=?,company_id=? WHERE dept_id=?');
            $st->execute([$name, $cid, $id]);
            flash('部門已更新');
        } else {
            $st = $pdo->prepare('INSERT INTO Department_Tab(company_id,dept_name) VALUES(?,?)');
            $st->execute([$cid, $name]);
            flash('部門已新增');
        }
        header('Location: companies.php');
        exit;
    }

    // 刪除公司
    if ($type === 'del_company') {
        $id = (int)$_POST['company_id'];
        $pdo->prepare('DELETE FROM Company_Tab WHERE company_id=?')->execute([$id]);
        flash('公司已刪除', 'error');
        header('Location: companies.php');
        exit;
    }

    // 刪除部門
    if ($type === 'del_dept') {
        $id = (int)$_POST['dept_id'];
        $pdo->prepare('DELETE FROM Department_Tab WHERE dept_id=?')->execute([$id]);
        flash('部門已刪除', 'error');
        header('Location: companies.php');
        exit;
    }
}

// ── 資料讀取 ─────────────────────────────────────────────────
$companies = $pdo->query('SELECT * FROM Company_Tab ORDER BY company_id')->fetchAll();
$depts     = $pdo->query(
    'SELECT d.*, c.company_name FROM Department_Tab d
     JOIN Company_Tab c ON d.company_id=c.company_id
     ORDER BY d.company_id, d.dept_id'
)->fetchAll();

// 編輯用
$editCompany = null;
$editDept    = null;
if ($action === 'edit_company' && isset($_GET['id'])) {
    $st = $pdo->prepare('SELECT * FROM Company_Tab WHERE company_id=?');
    $st->execute([(int)$_GET['id']]);
    $editCompany = $st->fetch();
}
if ($action === 'edit_dept' && isset($_GET['id'])) {
    $st = $pdo->prepare('SELECT * FROM Department_Tab WHERE dept_id=?');
    $st->execute([(int)$_GET['id']]);
    $editDept = $st->fetch();
}

require_once '_nav.php';
?>

<div class="page-header">
  <div class="page-title">公司 / 部門管理<small>設定多公司與部門組織</small></div>
  <div style="display:flex;gap:.5rem;">
    <button class="btn btn-primary" onclick="openModal('modalCompany')">🏢 新增公司</button>
    <button class="btn btn-success" onclick="openModal('modalDept')">🏬 新增部門</button>
  </div>
</div>

<div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;">

  <!-- 公司清單 -->
  <div class="card">
    <div class="card-header"><div class="card-title">🏢 公司列表</div></div>
    <div class="table-wrap">
      <table>
        <thead>
          <tr><th>#</th><th>公司名稱</th><th>統編</th><th>營業時間</th><th>操作</th></tr>
        </thead>
        <tbody>
          <?php foreach ($companies as $c): ?>
            <tr>
              <td class="text-muted"><?= $c['company_id'] ?></td>
              <td><strong><?= e($c['company_name']) ?></strong></td>
              <td><?= e($c['vat_number'] ?? '—') ?></td>
              <td><?= e($c['business_hours'] ?? '—') ?></td>
              <td>
                <div class="td-actions">
                  <a href="?action=edit_company&id=<?= $c['company_id'] ?>" class="btn btn-sm btn-secondary">✏️</a>
                  <form method="POST" id="dc<?= $c['company_id'] ?>">
                    <input type="hidden" name="type" value="del_company">
                    <input type="hidden" name="company_id" value="<?= $c['company_id'] ?>">
                    <button type="button" class="btn btn-sm btn-danger"
                      onclick="confirmDelete('確定刪除此公司及所有關聯資料嗎？','dc<?= $c['company_id'] ?>')">🗑️</button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$companies): ?>
            <tr><td colspan="5" class="text-center text-muted">尚無公司資料</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- 部門清單 -->
  <div class="card">
    <div class="card-header"><div class="card-title">🏬 部門列表</div></div>
    <div class="table-wrap">
      <table>
        <thead>
          <tr><th>#</th><th>部門名稱</th><th>所屬公司</th><th>操作</th></tr>
        </thead>
        <tbody>
          <?php foreach ($depts as $d): ?>
            <tr>
              <td class="text-muted"><?= $d['dept_id'] ?></td>
              <td><strong><?= e($d['dept_name']) ?></strong></td>
              <td><?= e($d['company_name']) ?></td>
              <td>
                <div class="td-actions">
                  <a href="?action=edit_dept&id=<?= $d['dept_id'] ?>" class="btn btn-sm btn-secondary">✏️</a>
                  <form method="POST" id="dd<?= $d['dept_id'] ?>">
                    <input type="hidden" name="type" value="del_dept">
                    <input type="hidden" name="dept_id" value="<?= $d['dept_id'] ?>">
                    <button type="button" class="btn btn-sm btn-danger"
                      onclick="confirmDelete('確定刪除此部門嗎？','dd<?= $d['dept_id'] ?>')">🗑️</button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$depts): ?>
            <tr><td colspan="4" class="text-center text-muted">尚無部門資料</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- 編輯公司（直接顯示在頁面下方）-->
<?php if ($editCompany): ?>
<div class="card mt-3">
  <div class="card-header"><div class="card-title">✏️ 編輯公司</div></div>
  <div class="card-body">
    <form method="POST">
      <input type="hidden" name="type" value="save_company">
      <input type="hidden" name="company_id" value="<?= $editCompany['company_id'] ?>">
      <div class="form-grid">
        <div class="form-group">
          <label class="form-label">公司名稱 <span class="req">*</span></label>
          <input type="text" name="company_name" class="form-control" value="<?= e($editCompany['company_name']) ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">統編</label>
          <input type="text" name="vat_number" class="form-control" value="<?= e($editCompany['vat_number'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label class="form-label">營業時間</label>
          <input type="text" name="business_hours" class="form-control" value="<?= e($editCompany['business_hours'] ?? '') ?>" placeholder="09:00~18:00">
        </div>
      </div>
      <div class="form-actions mt-2">
        <button type="submit" class="btn btn-primary">💾 儲存</button>
        <a href="companies.php" class="btn btn-secondary">取消</a>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<?php if ($editDept): ?>
<div class="card mt-3">
  <div class="card-header"><div class="card-title">✏️ 編輯部門</div></div>
  <div class="card-body">
    <form method="POST">
      <input type="hidden" name="type" value="save_dept">
      <input type="hidden" name="dept_id" value="<?= $editDept['dept_id'] ?>">
      <div class="form-grid">
        <div class="form-group">
          <label class="form-label">部門名稱 <span class="req">*</span></label>
          <input type="text" name="dept_name" class="form-control" value="<?= e($editDept['dept_name']) ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">所屬公司</label>
          <select name="company_id" class="form-control">
            <?php foreach ($companies as $c): ?>
              <option value="<?= $c['company_id'] ?>" <?= $c['company_id']==$editDept['company_id']?'selected':'' ?>>
                <?= e($c['company_name']) ?>
              </option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="form-actions mt-2">
        <button type="submit" class="btn btn-primary">💾 儲存</button>
        <a href="companies.php" class="btn btn-secondary">取消</a>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<!-- Modal：新增公司 -->
<div class="modal-overlay" id="modalCompany">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title">🏢 新增公司</div>
      <button class="modal-close" onclick="closeModal('modalCompany')">✕</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="type" value="save_company">
        <div class="form-grid">
          <div class="form-group full">
            <label class="form-label">公司名稱 <span class="req">*</span></label>
            <input type="text" name="company_name" class="form-control" placeholder="例：優力好照護有限公司" required>
          </div>
          <div class="form-group">
            <label class="form-label">統編（選填）</label>
            <input type="text" name="vat_number" class="form-control" placeholder="12345678" maxlength="10">
          </div>
          <div class="form-group">
            <label class="form-label">營業時間</label>
            <input type="text" name="business_hours" class="form-control" placeholder="09:00~18:00">
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('modalCompany')">取消</button>
        <button type="submit" class="btn btn-primary">💾 新增</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal：新增部門 -->
<div class="modal-overlay" id="modalDept">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title">🏬 新增部門</div>
      <button class="modal-close" onclick="closeModal('modalDept')">✕</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="type" value="save_dept">
        <div class="form-grid">
          <div class="form-group full">
            <label class="form-label">所屬公司 <span class="req">*</span></label>
            <select name="company_id" class="form-control">
              <?php foreach ($companies as $c): ?>
                <option value="<?= $c['company_id'] ?>"><?= e($c['company_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group full">
            <label class="form-label">部門名稱 <span class="req">*</span></label>
            <input type="text" name="dept_name" class="form-control" placeholder="例：照護部" required>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('modalDept')">取消</button>
        <button type="submit" class="btn btn-primary">💾 新增</button>
      </div>
    </form>
  </div>
</div>

<?php require_once '_footer.php'; ?>
