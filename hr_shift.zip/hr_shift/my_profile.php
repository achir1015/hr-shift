<?php
require_once __DIR__ . '/config.php';
$page_title = '個人資料';
$active     = 'my_profile';
requireLogin();

$pdo   = getDB();
$empId = currentEmpId();

// 管理員帳號（emp_id=0）沒有員工資料，跳到員工清單
if ($empId === 0) {
    header('Location: employees.php');
    exit;
}

// ── POST 儲存 ─────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone   = trim($_POST['phone']   ?? '');
    $email   = trim($_POST['email']   ?? '');
    $address = trim($_POST['address'] ?? '');
    $newpass = trim($_POST['emp_password'] ?? '');

    if ($newpass !== '') {
        $st = $pdo->prepare(
            'UPDATE Employee_Tab SET phone=?,email=?,address=?,emp_password=?
             WHERE emp_id=?'
        );
        $st->execute([$phone, $email, $address, md5($newpass), $empId]);
    } else {
        $st = $pdo->prepare(
            'UPDATE Employee_Tab SET phone=?,email=?,address=?
             WHERE emp_id=?'
        );
        $st->execute([$phone, $email, $address, $empId]);
    }
    flash('個人資料已更新');
    header('Location: my_profile.php');
    exit;
}

// ── 讀取自己的資料 ────────────────────────────────────────────
$st = $pdo->prepare(
    'SELECT e.*, d.dept_name FROM Employee_Tab e
     LEFT JOIN Department_Tab d ON e.dept_id=d.dept_id
     WHERE e.emp_id=?'
);
$st->execute([$empId]);
$emp = $st->fetch();

if (!$emp) {
    flash('找不到員工資料', 'error');
    header('Location: dashboard.php');
    exit;
}

require_once '_nav.php';
?>

<div class="page-header">
  <div class="page-title">
    個人資料
    <small>查看與修改自己的基本資訊及登入密碼</small>
  </div>
</div>

<!-- 基本資訊（唯讀顯示）-->
<div class="card mb-2">
  <div class="card-header"><div class="card-title">👤 基本資訊</div></div>
  <div class="card-body">
    <div class="form-grid">
      <div class="form-group">
        <label class="form-label">真實姓名</label>
        <div style="padding:.5rem .75rem;background:#f8fafc;border-radius:7px;border:1.5px solid var(--border);">
          <?= e($emp['real_name']) ?>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">所屬部門</label>
        <div style="padding:.5rem .75rem;background:#f8fafc;border-radius:7px;border:1.5px solid var(--border);">
          <?= e($emp['dept_name'] ?? '—') ?>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">工時型態</label>
        <div style="padding:.5rem .75rem;background:#f8fafc;border-radius:7px;border:1.5px solid var(--border);">
          <?= e($emp['work_type']) ?>
        </div>
      </div>
      <div class="form-group">
        <label class="form-label">帳號權限</label>
        <div style="padding:.5rem .75rem;background:#f8fafc;border-radius:7px;border:1.5px solid var(--border);">
          <?= e($emp['account_role']) ?>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- 可修改欄位 -->
<div class="card">
  <div class="card-header"><div class="card-title">✏️ 修改資料</div></div>
  <div class="card-body">
    <form method="POST">
      <div class="form-grid">
        <div class="form-group">
          <label class="form-label">手機號碼（登入帳號用）</label>
          <input type="tel" name="phone" class="form-control"
                 value="<?= e($emp['phone'] ?? '') ?>" placeholder="0912345678">
        </div>
        <div class="form-group">
          <label class="form-label">電子信箱（登入帳號用）</label>
          <input type="email" name="email" class="form-control"
                 value="<?= e($emp['email'] ?? '') ?>">
        </div>
        <div class="form-group full">
          <label class="form-label">住址（在家打卡基準）</label>
          <input type="text" name="address" class="form-control"
                 value="<?= e($emp['address'] ?? '') ?>" placeholder="台北市信義區...">
        </div>
        <div class="form-group">
          <label class="form-label">
            新密碼
            <span class="text-muted" style="font-weight:400;">（留空則不修改）</span>
          </label>
          <input type="password" name="emp_password" class="form-control"
                 placeholder="輸入新密碼" autocomplete="new-password">
        </div>
        <div class="form-group" style="align-self:flex-end;">
          <div class="text-sm text-muted" style="padding:.5rem 0;">
            💡 修改手機或 Email 後，下次登入請用新的帳號
          </div>
        </div>
      </div>
      <div class="form-actions mt-2">
        <button type="submit" class="btn btn-primary">💾 儲存</button>
      </div>
    </form>
  </div>
</div>

<?php require_once '_footer.php'; ?>
