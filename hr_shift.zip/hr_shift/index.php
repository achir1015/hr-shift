<?php
require_once __DIR__ . '/config.php';

if (!empty($_SESSION['hr_logged_in'])) {
    header('Location: dashboard.php');
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login'] ?? '');
    $pass  = trim($_POST['password'] ?? '');

    // ── 管理員帳號 ──────────────────────────────────────────
    if ($login === ADMIN_USER && $pass === ADMIN_PASS) {
        $pdo     = getDB();
        $company = $pdo->query('SELECT company_id, company_name FROM Company_Tab LIMIT 1')->fetch();
        $_SESSION['hr_logged_in']    = true;
        $_SESSION['hr_user_type']    = 'admin';
        $_SESSION['hr_role']         = 'admin';
        $_SESSION['hr_emp_id']       = 0;
        $_SESSION['hr_display_name'] = 'Admin';
        $_SESSION['hr_company_id']   = $company ? $company['company_id'] : 1;
        $_SESSION['hr_company_name'] = $company ? $company['company_name'] : '—';
        header('Location: dashboard.php');
        exit;
    }

    // ── 員工帳號（手機或 Email + 密碼）──────────────────────
    $pdo = getDB();
    $st  = $pdo->prepare(
        'SELECT e.*, c.company_name
         FROM Employee_Tab e
         JOIN Company_Tab c ON e.company_id = c.company_id
         WHERE (e.phone=? OR e.email=?) AND e.emp_password=?
         LIMIT 1'
    );
    $st->execute([$login, $login, md5($pass)]);
    $emp = $st->fetch();

    if ($emp) {
        $_SESSION['hr_logged_in']    = true;
        $_SESSION['hr_user_type']    = 'employee';
        $_SESSION['hr_role']         = $emp['account_role'];
        $_SESSION['hr_emp_id']       = $emp['emp_id'];
        $_SESSION['hr_display_name'] = $emp['real_name'];
        $_SESSION['hr_company_id']   = $emp['company_id'];
        $_SESSION['hr_company_name'] = $emp['company_name'];
        header('Location: dashboard.php');
        exit;
    }

    $error = '帳號或密碼錯誤，請重新輸入。';
}
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>登入 — <?= SYS_NAME ?></title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="login-page">
  <div class="login-card">
    <div class="login-logo">
      <div class="logo-icon">📅</div>
      <div class="logo-text">
        <div class="logo-name"><?= SYS_NAME ?></div>
        <div class="logo-sub">Smart Shift Management</div>
      </div>
    </div>
    <h2>歡迎回來</h2>
    <p class="sub">員工請輸入手機號碼或 Email；管理員輸入 admin</p>
    <?php if ($error): ?>
      <div class="flash flash-error">⚠️ <?= e($error) ?></div>
    <?php endif; ?>
    <form method="POST">
      <div class="form-group mb-2">
        <label class="form-label">帳號（手機 / Email / admin）</label>
        <input type="text" name="login" class="form-control"
               placeholder="0912345678 或 admin"
               value="<?= e(isset($_POST['login']) ? $_POST['login'] : '') ?>"
               autocomplete="username" required>
      </div>
      <div class="form-group mb-1">
        <label class="form-label">密碼</label>
        <input type="password" name="password" class="form-control"
               placeholder="••••••••" autocomplete="current-password" required>
      </div>
      <button type="submit" class="login-btn">🔓 &nbsp;登入系統</button>
    </form>
    <p class="login-hint">系統管理員：admin / admin1234<br>員工帳號請洽管理者設定密碼</p>
  </div>
</div>
</body>
</html>
