    </div><!-- /.content -->
  </div><!-- /.main -->
</div><!-- /.layout -->

<script>
// ── 側邊欄開關（手機版）────────────────────────────────────
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
  document.getElementById('sideOverlay').classList.toggle('open');
}
function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sideOverlay').classList.remove('open');
}

// ── Modal 工具 ───────────────────────────────────────────
function openModal(id) {
  document.getElementById(id).classList.add('open');
}
function closeModal(id) {
  document.getElementById(id).classList.remove('open');
}
// 按 Esc 關閉 modal
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    document.querySelectorAll('.modal-overlay.open')
      .forEach(m => m.classList.remove('open'));
  }
});
// 點擊背景關閉 modal
document.querySelectorAll('.modal-overlay').forEach(overlay => {
  overlay.addEventListener('click', function(e) {
    if (e.target === this) this.classList.remove('open');
  });
});

// ── 確認刪除 ─────────────────────────────────────────────
function confirmDelete(msg, formId) {
  if (confirm(msg || '確定要刪除嗎？')) {
    document.getElementById(formId).submit();
  }
}
</script>
</body>
</html>
