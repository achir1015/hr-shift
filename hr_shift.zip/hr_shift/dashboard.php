<?php
require_once __DIR__ . '/config.php';
$page_title = '儀表板';
$active     = 'dashboard';
require_once '_nav.php';

$pdo = getDB();
$cid = currentCompanyId();

// ── 統計數字 ─────────────────────────────────────────────────
$emp_count   = $pdo->prepare('SELECT COUNT(*) FROM Employee_Tab WHERE company_id=?');
$emp_count->execute([$cid]);
$total_emp   = $emp_count->fetchColumn();

$dept_count  = $pdo->prepare('SELECT COUNT(*) FROM Department_Tab WHERE company_id=?');
$dept_count->execute([$cid]);
$total_dept  = $dept_count->fetchColumn();

$shift_count = $pdo->prepare('SELECT COUNT(*) FROM Shift_Type_Tab WHERE company_id=? AND is_holiday=0');
$shift_count->execute([$cid]);
$total_shifts = $shift_count->fetchColumn();

// 今日打卡數（所有員工）
$today_punch = $pdo->prepare(
    'SELECT COUNT(*) FROM Attendance_Tab a
     JOIN Employee_Tab e ON a.emp_id = e.emp_id
     WHERE e.company_id=? AND DATE(a.punch_time)=CURDATE()'
);
$today_punch->execute([$cid]);
$total_today_punch = $today_punch->fetchColumn();

// 本月應出勤天數（Schedule_Detail 已排班）
$this_month_sched = $pdo->prepare(
    'SELECT COUNT(*) FROM Schedule_Detail sd
     JOIN Employee_Tab e ON sd.emp_id = e.emp_id
     WHERE e.company_id=? AND DATE_FORMAT(sd.work_date,"%Y-%m")=DATE_FORMAT(CURDATE(),"%Y-%m")
       AND sd.shift_id IS NOT NULL'
);
$this_month_sched->execute([$cid]);
$total_sched_this_month = $this_month_sched->fetchColumn();

// 最近異常打卡
$abnormal = $pdo->prepare(
    'SELECT a.punch_time, a.punch_method, e.real_name
     FROM Attendance_Tab a
     JOIN Employee_Tab e ON a.emp_id = e.emp_id
     WHERE e.company_id=? AND a.is_abnormal=1
     ORDER BY a.punch_time DESC LIMIT 5'
);
$abnormal->execute([$cid]);
$abnormals = $abnormal->fetchAll();

// 最近排班主檔
$recent_sch = $pdo->prepare(
    'SELECT schedule_id, date_range_start, date_range_end, status, created_at
     FROM Schedule_Master WHERE company_id=?
     ORDER BY created_at DESC LIMIT 5'
);
$recent_sch->execute([$cid]);
$recent_schedules = $recent_sch->fetchAll();

// 本月統計摘要
$month_stats = $pdo->prepare(
    'SELECT SUM(total_work_hours) as hrs, SUM(est_salary) as sal, COUNT(*) as emp_cnt
     FROM Monthly_Stats_Tab ms
     JOIN Employee_Tab e ON ms.emp_id=e.emp_id
     WHERE e.company_id=? AND ms.year_month=DATE_FORMAT(CURDATE(),"%Y-%m")'
);
$month_stats->execute([$cid]);
$mstats = $month_stats->fetch();
?>

<div class="page-header">
  <div class="page-title">
    儀表板
    <small><?= date('Y 年 m 月 d 日') ?> &nbsp;(<?= ['日','一','二','三','四','五','六'][date('w')] ?>)</small>
  </div>
</div>

<!-- 統計卡片 -->
<div class="stats-grid">
  <div class="stat-card">
    <div class="stat-icon cyan">👤</div>
    <div>
      <div class="stat-value"><?= $total_emp ?></div>
      <div class="stat-label">員工人數</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon green">🏬</div>
    <div>
      <div class="stat-value"><?= $total_dept ?></div>
      <div class="stat-label">部門數</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon amber">⏰</div>
    <div>
      <div class="stat-value"><?= $total_shifts ?></div>
      <div class="stat-label">班別設定</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon blue">📍</div>
    <div>
      <div class="stat-value"><?= $total_today_punch ?></div>
      <div class="stat-label">今日打卡次數</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon rose">📅</div>
    <div>
      <div class="stat-value"><?= $total_sched_this_month ?></div>
      <div class="stat-label">本月排班筆數</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon green">💰</div>
    <div>
      <div class="stat-value" style="font-size:1.2rem"><?= number_format($mstats['sal'] ?? 0) ?></div>
      <div class="stat-label">本月預估薪資 (元)</div>
    </div>
  </div>
</div>

<!-- 主要內容二欄 -->
<div style="display:grid;grid-template-columns:1fr 1fr;gap:1rem;margin-bottom:1rem;">

  <!-- 最近排班 -->
  <div class="card">
    <div class="card-header">
      <div class="card-title">📅 最近排班表</div>
      <a href="schedule.php" class="btn btn-sm btn-outline">查看全部</a>
    </div>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>班表期間</th>
            <th>狀態</th>
            <th>建立時間</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($recent_schedules): ?>
            <?php foreach ($recent_schedules as $s): ?>
              <tr>
                <td><?= e($s['date_range_start']) ?> ~ <?= e($s['date_range_end']) ?></td>
                <td>
                  <?php if ($s['status'] === '已發布'): ?>
                    <span class="badge badge-green">✅ 已發布</span>
                  <?php else: ?>
                    <span class="badge badge-amber">✏️ 草稿</span>
                  <?php endif; ?>
                </td>
                <td class="text-muted text-sm"><?= e(substr($s['created_at'],0,10)) ?></td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr><td colspan="3" class="text-center text-muted">尚無排班表</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- 異常打卡 -->
  <div class="card">
    <div class="card-header">
      <div class="card-title">⚠️ 近期異常打卡</div>
      <a href="attendance.php?abnormal=1" class="btn btn-sm btn-outline">查看全部</a>
    </div>
    <div class="table-wrap">
      <table>
        <thead>
          <tr>
            <th>員工</th>
            <th>打卡時間</th>
            <th>方式</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($abnormals): ?>
            <?php foreach ($abnormals as $a): ?>
              <tr>
                <td><?= e($a['real_name']) ?></td>
                <td class="text-sm"><?= e($a['punch_time']) ?></td>
                <td><span class="badge badge-red"><?= e($a['punch_method']) ?></span></td>
              </tr>
            <?php endforeach; ?>
          <?php else: ?>
            <tr><td colspan="3" class="text-center text-muted">🎉 近期無異常打卡</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- 快速功能 -->
<div class="card">
  <div class="card-header"><div class="card-title">🚀 快速功能</div></div>
  <div class="card-body" style="display:flex;gap:.75rem;flex-wrap:wrap;">
    <a href="employees.php?action=add" class="btn btn-primary">👤 新增員工</a>
    <a href="schedule.php?action=add"  class="btn btn-success">📅 新建排班表</a>
    <a href="shifts.php?action=add"    class="btn btn-warning">⏰ 新增班別</a>
    <a href="stats.php"                class="btn btn-secondary">📊 查看月報表</a>
    <a href="attendance.php"           class="btn btn-secondary">📍 打卡紀錄</a>
  </div>
</div>

<?php require_once '_footer.php'; ?>
