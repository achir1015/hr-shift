<?php
// ============================================================
//  排班管理系統 - 核心設定檔
//  資料庫：hr_shift_db（獨立，與主站分離）
// ============================================================

session_start();

// ── 資料庫連線參數 ──────────────────────────────────────────
define('DB_HOST',    '127.0.0.1:3307'); // ← MariaDB 10
define('DB_NAME',    'hr_shift_db');
define('DB_USER',    'root');           // ← 您的 MySQL 帳號
define('DB_PASS',    'Athena120083530@'); // ← ⚠️ 上傳前務必改成正確密碼
define('DB_CHARSET', 'utf8mb4');

// ── 系統設定 ────────────────────────────────────────────────
define('SYS_NAME',    '排班管理系統');
define('SYS_VERSION', '1.0.0');

// ── 預設管理員（第一次使用，之後可改為資料表管理）────────────
define('ADMIN_USER', 'admin');
define('ADMIN_PASS', 'admin1234');  // ← 上線後請修改

// ── PDO 單例連線（PHP 5.6+ 相容）────────────────────────────
function getDB() {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
            $pdo = new PDO($dsn, DB_USER, DB_PASS, array(
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ));
        } catch (PDOException $e) {
            // 顯示友善錯誤頁
            http_response_code(500);
            die('<div style="font-family:sans-serif;padding:2rem;color:#dc2626;">
                    <h2>&#9888; 資料庫連線失敗</h2>
                    <p>請確認 config.php 中的 DB_HOST / DB_USER / DB_PASS 設定是否正確。</p>
                    <code>' . htmlspecialchars($e->getMessage()) . '</code>
                 </div>');
        }
    }
    return $pdo;
}

// ── Flash 訊息（移除型態宣告，相容 PHP 5.6+）────────────────
function flash($msg, $type = 'success') {
    $_SESSION['flash'] = array('msg' => $msg, 'type' => $type);
}

function getFlash() {
    if (isset($_SESSION['flash'])) {
        $f = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $f;
    }
    return null;
}

// ── 安全輸出（移除 mixed 型態，相容 PHP 5.6+）──────────────
function e($v) {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

// ── 登入狀態檢查（移除 void 回傳型態）──────────────────────
function requireLogin() {
    if (empty($_SESSION['hr_logged_in'])) {
        header('Location: index.php');
        exit;
    }
}

// ── 取得目前登入的公司 ID（移除 int 回傳型態）──────────────
function currentCompanyId() {
    return isset($_SESSION['hr_company_id']) ? (int)$_SESSION['hr_company_id'] : 1;
}

// ── 取得目前登入的員工 ID（0 = 管理員帳號）──────────────────
function currentEmpId() {
    return isset($_SESSION['hr_emp_id']) ? (int)$_SESSION['hr_emp_id'] : 0;
}

// ── 取得目前角色 ─────────────────────────────────────────────
// 回傳：'admin'（系統管理）/ '管理者' / '一般員工' / '外部帳號'
function currentRole() {
    return isset($_SESSION['hr_role']) ? $_SESSION['hr_role'] : 'admin';
}

// ── 是否為管理層（可看全部資料）─────────────────────────────
function isManager() {
    $role = currentRole();
    return ($role === 'admin' || $role === '管理者');
}

// ── 管理層專用頁面，非管理層跳回儀表板 ─────────────────────
function requireManager() {
    requireLogin();
    if (!isManager()) {
        header('Location: dashboard.php');
        exit;
    }
}
