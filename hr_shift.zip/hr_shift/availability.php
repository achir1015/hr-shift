<?php
require_once __DIR__ . '/config.php';
$page_title = '行事曆同步';
$active     = 'availability';

$pdo = getDB();
$cid = currentCompanyId();

// ── POST 處理 ─────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'] ?? '';

    if ($type === 'save') {
        $emp_id   = (int)$_POST['emp_id'];
        $date     = $_POST['avail_date'];
        $avail    = isset($_POST['is_available']) ? 1 : 0;
        $source   = $_POST['source'];

        // UPSERT：每人每天唯一
        $st = $pdo->prepare(
            'INSERT INTO Employee_Availability_Tab(emp_id,avail_date,is_available,source)
             VALUES(?,?,?,?)
             ON DUPLICATE KEY UPDATE is_available=VALUES(is_available), source=VALUES(source)'
        );
        $st->execute([$emp_id, $date, $avail, $source]);
        flash('行事曆狀態已更新');
        header('Location: availability.php');
        exit;
    }

    if ($type === 'delete') {
        $id = (int)$_POST['sync_id'];
        $pdo->prepare('DELETE FROM Employee_Availability_Tab WHERE sync_id=?')->execute([$id]);
        flash('紀錄已刪除', 'error');
        header('Location: availability.php');
        exit;
    }

    // 批次設定（一個員工一週）
    if ($type === 'batch') {
        $emp_id = (int)$_POST['emp_id'];
        $start  = $_POST['batch_start'];
        $end    = $_POST['batch_end'];
        $avail  = (int)$_POST['batch_avail'];
        $source = '手動';

        $cur = new DateTime($start);
        $endDt = new DateTime($end);
        $st = $pdo->prepare(
            'INSERT INTO Employee_Availability_Tab(emp_id,avail_date,is_available,source)
             VALUES(?,?,?,?)
             ON DUPLICATE KEY UPDATE is_available=VALUES(is_available), source=VALUES(source)'
        );
        while ($cur <= $endDt) {
            $st->execute([$emp_id, $cur->format('Y-m-d'), $avail, $source]);
            $cur->modify('+1 day');
        }
        flash('批次設定完成');
        header('Location: availability.php');
        exit;
    }
}

// ── 讀取 ─────────────────────────────────────────────────────
$filterEmp  = (int)($_GET['emp_id'] ?? 0);
$filterMonth = trim($_GET['month'] ?? date('Y-m'));

$emps = $pdo->prepare('SELECT emp_id, real_name FROM Employee_Tab WHERE company_id=? ORDER BY real_name');
$emps->execute([$cid]);
$emps = $emps->fetchAll();

$where  = ['e.company_id=?', "DATE_FORMAT(a.avail_date,'%Y-%m')=?"];
$params = [$cid, $filterMonth];
if ($filterEmp) {
    $where[]  = 'a.emp_id=?';
    $params[] = $filterEmp;
}

$sql = 'SELECT a.*, e.real_name FROM Employee_Availability_Tab a
        JOIN Employee_Tab e ON a.emp_id=e.emp_id
        WHERE ' . implode(' AND ', $where) . '
        ORDER BY a.avail_date, e.real_name';
$stData = $pdo->prepare($sql);
$stData->execute($params);
$records = $stData->fetchAll();

// 不可用員工（本月沒空）
$unavail = array_filter($records, function($r) { return !$r['is_available']; });

require_once '_nav.php';
?>

<div class="page-header">
  <div class="page-title">行事曆同步<small>員工可用性管理，供智能排班參考</small></div>
  <div style="display:flex;gap:.5rem;">
    <button class="btn btn-primary" onclick="openModal('modalAdd')">➕ 新增狀態</button>
    <button class="btn btn-warning" onclick="openModal('modalBatch')">📆 批次設定</button>
  </div>
</div>

<!-- 說明 -->
<div class="card mb-2" style="border-left:4px solid var(--warning);">
  <div class="card-body" style="padding:.8rem 1rem;">
    <span class="text-sm">
      ⚡ <strong>智能排班邏輯：</strong>
      員工標記為「沒空」時，系統在智能排班時會主動略過該員工，優先安排其他有空的員工。
      管理者端不顯示私人行程明細，僅顯示「有空 / 沒空」狀態。
    </span>
  </div>
</div>

<!-- 篩選 -->
<form method="GET" class="card mb-2">
  <div class="card-body" style="padding:.8rem 1rem;display:flex;gap:.6rem;flex-wrap:wrap;align-items:flex-end;">
    <div class="form-group" style="margin:0;">
      <label class="form-label">員工</label>
      <select name="emp_id" class="form-control">
        <option value="">全部員工</option>
        <?php foreach ($emps as $e): ?>
          <option value="<?= $e['emp_id'] ?>" <?= $filterEmp==$e['emp_id']?'selected':'' ?>>
            <?= e($e['real_name']) ?>
          </option>
        <?php endforeach; ?>
      </select>
    </div>
    <div class="form-group" style="margin:0;">
      <label class="form-label">月份</label>
      <input type="month" name="month" class="form-control" value="<?= e($filterMonth) ?>">
    </div>
    <div style="align-self:flex-end;display:flex;gap:.4rem;">
      <button type="submit" class="btn btn-primary btn-sm">🔍 篩選</button>
      <a href="availability.php" class="btn btn-secondary btn-sm">清除</a>
    </div>
  </div>
</form>

<!-- 本月沒空員工摘要 -->
<?php if ($unavail): ?>
<div class="card mb-2" style="border-left:4px solid var(--danger);">
  <div class="card-header"><div class="card-title">⛔ 本月有「沒空」設定的員工</div></div>
  <div class="card-body" style="display:flex;flex-wrap:wrap;gap:.5rem;padding:.75rem 1rem;">
    <?php
      $unavailNames = array_unique(array_column(iterator_to_array((function() use ($unavail) {
        yield from $unavail;
      })()), 'real_name'));
      foreach ($unavailNames as $name):
    ?>
      <span class="badge badge-red">🚫 <?= e($name) ?></span>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>

<!-- 清單 -->
<div class="card">
  <div class="card-header">
    <div class="card-title">📆 可用性紀錄</div>
    <span class="badge badge-cyan"><?= count($records) ?> 筆</span>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr><th>員工</th><th>日期</th><th>狀態</th><th>來源</th><th>同步時間</th><th>操作</th></tr>
      </thead>
      <tbody>
        <?php if ($records): ?>
          <?php foreach ($records as $r): ?>
            <tr>
              <td><strong><?= e($r['real_name']) ?></strong></td>
              <td><?= e($r['avail_date']) ?></td>
              <td>
                <?php if ($r['is_available']): ?>
                  <span class="badge badge-green">✅ 有空</span>
                <?php else: ?>
                  <span class="badge badge-red">🚫 沒空</span>
                <?php endif; ?>
              </td>
              <td>
                <?php
                  $sb = ['Google'=>'badge-blue','iOS'=>'badge-cyan','手動'=>'badge-gray'];
                ?>
                <span class="badge <?= $sb[$r['source']] ?? 'badge-gray' ?>">
                  <?= e($r['source']) ?>
                </span>
              </td>
              <td class="text-sm text-muted"><?= e(substr($r['synced_at'],0,16)) ?></td>
              <td>
                <form method="POST" id="da<?= $r['sync_id'] ?>">
                  <input type="hidden" name="type" value="delete">
                  <input type="hidden" name="sync_id" value="<?= $r['sync_id'] ?>">
                  <button type="button" class="btn btn-xs btn-danger"
                    onclick="confirmDelete('確定刪除此紀錄嗎？','da<?= $r['sync_id'] ?>')">🗑️</button>
                </form>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr><td colspan="6"><div class="empty-state"><div class="icon">📆</div><p>尚無行事曆同步紀錄</p></div></td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal：新增單筆 -->
<div class="modal-overlay" id="modalAdd">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title">➕ 新增可用性設定</div>
      <button class="modal-close" onclick="closeModal('modalAdd')">✕</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="type" value="save">
        <div class="form-grid">
          <div class="form-group full">
            <label class="form-label">員工 <span class="req">*</span></label>
            <select name="emp_id" class="form-control" required>
              <option value="">請選擇</option>
              <?php foreach ($emps as $e): ?>
                <option value="<?= $e['emp_id'] ?>"><?= e($e['real_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">日期 <span class="req">*</span></label>
            <input type="date" name="avail_date" class="form-control" value="<?= date('Y-m-d') ?>" required>
          </div>
          <div class="form-group">
            <label class="form-label">來源</label>
            <select name="source" class="form-control">
              <option value="手動">手動</option>
              <option value="Google">Google 行事曆</option>
              <option value="iOS">iOS 行事曆</option>
            </select>
          </div>
          <div class="form-group full">
            <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer;">
              <input type="checkbox" name="is_available" value="1" checked>
              <span>當天有空（未勾選 = 沒空）</span>
            </label>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('modalAdd')">取消</button>
        <button type="submit" class="btn btn-primary">💾 儲存</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal：批次設定 -->
<div class="modal-overlay" id="modalBatch">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title">📆 批次設定可用性</div>
      <button class="modal-close" onclick="closeModal('modalBatch')">✕</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="type" value="batch">
        <p class="text-sm text-muted mb-2">一次設定某員工某段日期的可用性狀態</p>
        <div class="form-grid">
          <div class="form-group full">
            <label class="form-label">員工 <span class="req">*</span></label>
            <select name="emp_id" class="form-control" required>
              <option value="">請選擇</option>
              <?php foreach ($emps as $e): ?>
                <option value="<?= $e['emp_id'] ?>"><?= e($e['real_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">開始日期</label>
            <input type="date" name="batch_start" class="form-control" value="<?= date('Y-m-d') ?>">
          </div>
          <div class="form-group">
            <label class="form-label">結束日期</label>
            <input type="date" name="batch_end" class="form-control" value="<?= date('Y-m-d',strtotime('+6 days')) ?>">
          </div>
          <div class="form-group full">
            <label class="form-label">狀態</label>
            <select name="batch_avail" class="form-control">
              <option value="1">✅ 有空</option>
              <option value="0">🚫 沒空</option>
            </select>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('modalBatch')">取消</button>
        <button type="submit" class="btn btn-warning">📆 批次設定</button>
      </div>
    </form>
  </div>
</div>

<?php require_once '_footer.php'; ?>
