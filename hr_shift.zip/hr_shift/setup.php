<?php
// ============================================================
//  排班管理系統 — 一鍵安裝頁
//  開啟此頁後自動建立資料庫與所有資料表
//  安裝完成後請刪除此檔案
// ============================================================

// ── 資料庫連線設定（與 config.php 相同，請確認已修改正確）──
$DB_HOST    = '127.0.0.1:3307';
$DB_USER    = 'root';       // ← 改成您的 MySQL 帳號
$DB_PASS    = 'Athena120083530@';           // ← 改成您的 MySQL 密碼
$DB_NAME    = 'hr_shift_db';
$DB_CHARSET = 'utf8mb4';

$logs   = array();
$errors = array();

function log_ok($msg) {
    global $logs;
    $logs[] = $msg;
}
function log_err($msg) {
    global $errors;
    $errors[] = $msg;
}

// ── Step 1：不指定 DB，先測試帳號密碼能否連線 ──────────────
try {
    //$dsn = 'mysql:host=' . $DB_HOST . ';charset=' . $DB_CHARSET;
    $dsn = 'mysql:host=127.0.0.1;port=3307;charset=' . $DB_CHARSET;
    $pdo = new PDO($dsn, $DB_USER, $DB_PASS, array(
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    ));
    log_ok('✅ MySQL 連線成功（帳號密碼正確）');
} catch (PDOException $e) {
    log_err('❌ MySQL 連線失敗：' . $e->getMessage());
    $pdo = null;
}

// ── Step 2：建立資料庫 ──────────────────────────────────────
if ($pdo) {
    try {
        $pdo->exec("CREATE DATABASE IF NOT EXISTS `$DB_NAME`
                    CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
        log_ok("✅ 資料庫 `$DB_NAME` 已建立（或已存在）");
        $pdo->exec("USE `$DB_NAME`");
    } catch (PDOException $e) {
        log_err('❌ 建立資料庫失敗：' . $e->getMessage());
        $pdo = null;
    }
}

// ── Step 3：建立所有資料表 ──────────────────────────────────
$tables = array();

// ── 注意：舊版 MySQL 不支援 DATETIME DEFAULT CURRENT_TIMESTAMP
//         統一改用 TIMESTAMP 型態解決相容性問題 ──────────────

$tables['Company_Tab'] = "CREATE TABLE IF NOT EXISTS `Company_Tab` (
  `company_id`     INT           NOT NULL AUTO_INCREMENT,
  `company_name`   VARCHAR(100)  NOT NULL,
  `vat_number`     VARCHAR(10)   NULL,
  `business_hours` VARCHAR(255)  NULL,
  `account_mgr_id` INT           NOT NULL DEFAULT 1,
  `created_at`     TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`company_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

$tables['Department_Tab'] = "CREATE TABLE IF NOT EXISTS `Department_Tab` (
  `dept_id`    INT          NOT NULL AUTO_INCREMENT,
  `company_id` INT          NOT NULL,
  `dept_name`  VARCHAR(50)  NOT NULL,
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`dept_id`),
  FOREIGN KEY (`company_id`) REFERENCES `Company_Tab`(`company_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

$tables['Employee_Tab'] = "CREATE TABLE IF NOT EXISTS `Employee_Tab` (
  `emp_id`         INT            NOT NULL AUTO_INCREMENT,
  `company_id`     INT            NOT NULL,
  `dept_id`        INT            NOT NULL,
  `real_name`      VARCHAR(50)    NOT NULL,
  `id_card`        VARCHAR(10)    NOT NULL DEFAULT '',
  `phone`          VARCHAR(20)    NULL,
  `email`          VARCHAR(100)   NULL,
  `address`        VARCHAR(255)   NULL,
  `work_type`      ENUM('正常工時','變形工時','兼職') NOT NULL DEFAULT '正常工時',
  `account_role`   ENUM('一般員工','管理者','外部帳號') NOT NULL DEFAULT '一般員工',
  `hourly_wage`    DECIMAL(8,2)   NULL,
  `monthly_salary` DECIMAL(10,2)  NULL,
  `emp_password`   VARCHAR(32)    NULL COMMENT 'MD5密碼，員工登入用',
  `created_at`     TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`emp_id`),
  FOREIGN KEY (`company_id`) REFERENCES `Company_Tab`(`company_id`) ON DELETE RESTRICT,
  FOREIGN KEY (`dept_id`)    REFERENCES `Department_Tab`(`dept_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

$tables['Shift_Type_Tab'] = "CREATE TABLE IF NOT EXISTS `Shift_Type_Tab` (
  `shift_id`    INT           NOT NULL AUTO_INCREMENT,
  `company_id`  INT           NOT NULL,
  `shift_name`  VARCHAR(50)   NOT NULL,
  `start_time`  TIME          NOT NULL,
  `end_time`    TIME          NOT NULL,
  `rest_time`   INT           NOT NULL DEFAULT 60,
  `total_hours` DECIMAL(4,1)  NOT NULL,
  `color_code`  VARCHAR(10)   NULL,
  `is_holiday`  TINYINT(1)    NOT NULL DEFAULT 0,
  `created_at`  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`shift_id`),
  FOREIGN KEY (`company_id`) REFERENCES `Company_Tab`(`company_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

$tables['Schedule_Master'] = "CREATE TABLE IF NOT EXISTS `Schedule_Master` (
  `schedule_id`      INT       NOT NULL AUTO_INCREMENT,
  `company_id`       INT       NOT NULL,
  `date_range_start` DATE      NOT NULL,
  `date_range_end`   DATE      NOT NULL,
  `status`           ENUM('草稿','已發布') NOT NULL DEFAULT '草稿',
  `published_at`     TIMESTAMP NULL DEFAULT NULL,
  `created_at`       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`schedule_id`),
  FOREIGN KEY (`company_id`) REFERENCES `Company_Tab`(`company_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

$tables['Schedule_Detail'] = "CREATE TABLE IF NOT EXISTS `Schedule_Detail` (
  `detail_id`   INT          NOT NULL AUTO_INCREMENT,
  `schedule_id` INT          NOT NULL,
  `emp_id`      INT          NOT NULL,
  `work_date`   DATE         NOT NULL,
  `day_of_week` VARCHAR(3)   NULL,
  `shift_id`    INT          NULL,
  `remark`      VARCHAR(100) NULL,
  `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`detail_id`),
  UNIQUE KEY `uq_sch_emp_date` (`schedule_id`,`emp_id`,`work_date`),
  FOREIGN KEY (`schedule_id`) REFERENCES `Schedule_Master`(`schedule_id`) ON DELETE CASCADE,
  FOREIGN KEY (`emp_id`)      REFERENCES `Employee_Tab`(`emp_id`)     ON DELETE RESTRICT,
  FOREIGN KEY (`shift_id`)    REFERENCES `Shift_Type_Tab`(`shift_id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

$tables['Attendance_Tab'] = "CREATE TABLE IF NOT EXISTS `Attendance_Tab` (
  `punch_id`       INT            NOT NULL AUTO_INCREMENT,
  `emp_id`         INT            NOT NULL,
  `punch_time`     DATETIME       NOT NULL,
  `punch_method`   ENUM('GPS','WIFI') NOT NULL DEFAULT 'GPS',
  `location_valid` TINYINT(1)     NOT NULL DEFAULT 0,
  `is_abnormal`    TINYINT(1)     NOT NULL DEFAULT 0,
  `latitude`       DECIMAL(10,7)  NULL,
  `longitude`      DECIMAL(10,7)  NULL,
  `created_at`     TIMESTAMP      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`punch_id`),
  FOREIGN KEY (`emp_id`) REFERENCES `Employee_Tab`(`emp_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

$tables['Employee_Availability_Tab'] = "CREATE TABLE IF NOT EXISTS `Employee_Availability_Tab` (
  `sync_id`      INT        NOT NULL AUTO_INCREMENT,
  `emp_id`       INT        NOT NULL,
  `avail_date`   DATE       NOT NULL,
  `is_available` TINYINT(1) NOT NULL DEFAULT 1,
  `source`       ENUM('Google','iOS','手動') NOT NULL DEFAULT '手動',
  `synced_at`    TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`sync_id`),
  UNIQUE KEY `uq_emp_date` (`emp_id`,`avail_date`),
  FOREIGN KEY (`emp_id`) REFERENCES `Employee_Tab`(`emp_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

$tables['Monthly_Stats_Tab'] = "CREATE TABLE IF NOT EXISTS `Monthly_Stats_Tab` (
  `stat_id`           INT           NOT NULL AUTO_INCREMENT,
  `emp_id`            INT           NOT NULL,
  `year_month`        VARCHAR(7)    NOT NULL,
  `total_work_days`   INT           NOT NULL DEFAULT 0,
  `total_work_hours`  DECIMAL(6,2)  NOT NULL DEFAULT 0,
  `overtime_hours`    DECIMAL(6,2)  NOT NULL DEFAULT 0,
  `holiday_work_days` INT           NOT NULL DEFAULT 0,
  `est_salary`        DECIMAL(10,2) NOT NULL DEFAULT 0,
  `is_finalized`      TINYINT(1)    NOT NULL DEFAULT 0,
  `created_at`        TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`        DATETIME      NULL DEFAULT NULL,
  PRIMARY KEY (`stat_id`),
  UNIQUE KEY `uq_emp_month` (`emp_id`,`year_month`),
  FOREIGN KEY (`emp_id`) REFERENCES `Employee_Tab`(`emp_id`) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4";

if ($pdo) {
    foreach ($tables as $name => $sql) {
        try {
            $pdo->exec($sql);
            log_ok("✅ 資料表 `$name` 已建立");
        } catch (PDOException $e) {
            log_err("❌ 建立 `$name` 失敗：" . $e->getMessage());
        }
    }
}

// ── Step 4.5：補丁 — 若舊資料庫缺少 emp_password 欄位則新增 ─
if ($pdo && empty($errors)) {
    try {
        $cols = $pdo->query("SHOW COLUMNS FROM `Employee_Tab` LIKE 'emp_password'")->fetchAll();
        if (empty($cols)) {
            $pdo->exec("ALTER TABLE `Employee_Tab`
                        ADD COLUMN `emp_password` VARCHAR(32) NULL COMMENT 'MD5密碼，員工登入用'
                        AFTER `monthly_salary`");
            log_ok('✅ emp_password 欄位已新增到 Employee_Tab');
        } else {
            log_ok('ℹ️ emp_password 欄位已存在，略過');
        }
    } catch (PDOException $e) {
        log_err('❌ 新增 emp_password 欄位失敗：' . $e->getMessage());
    }
}

// ── Step 5：插入初始資料（若 Company_Tab 是空的才插）──────
if ($pdo && empty($errors)) {
    try {
        $count = $pdo->query('SELECT COUNT(*) FROM `Company_Tab`')->fetchColumn();
        if ($count == 0) {
            $pdo->exec("INSERT INTO `Company_Tab`(`company_name`,`business_hours`,`account_mgr_id`)
                        VALUES('我的公司','09:00~18:00',1)");
            $pdo->exec("INSERT INTO `Department_Tab`(`company_id`,`dept_name`)
                        VALUES(1,'照護部'),(1,'行政部')");
            $pdo->exec("INSERT INTO `Shift_Type_Tab`
                        (`company_id`,`shift_name`,`start_time`,`end_time`,`rest_time`,`total_hours`,`color_code`,`is_holiday`)
                        VALUES
                        (1,'早班','07:00:00','15:00:00',60,8.0,'#4A90E2',0),
                        (1,'晚班','15:00:00','23:00:00',60,8.0,'#F5A623',0),
                        (1,'大夜班','23:00:00','07:00:00',60,8.0,'#7B68EE',0),
                        (1,'休假','00:00:00','00:00:00',0,0.0,'#AAAAAA',1)");
            log_ok('✅ 初始資料已插入（公司、部門、班別）');
        } else {
            log_ok('ℹ️ 已有資料，跳過初始資料插入');
        }
    } catch (PDOException $e) {
        log_err('❌ 插入初始資料失敗：' . $e->getMessage());
    }
}

$success = empty($errors);
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>排班系統 — 安裝程式</title>
<style>
  body { font-family: sans-serif; background:#0f172a; color:#f1f5f9; display:flex; justify-content:center; align-items:center; min-height:100vh; margin:0; padding:1rem; }
  .box { background:#1e293b; border-radius:14px; padding:2rem; width:100%; max-width:560px; }
  h1 { font-size:1.3rem; margin-bottom:.3rem; }
  .sub { color:#94a3b8; font-size:.85rem; margin-bottom:1.5rem; }
  .log-item { padding:.45rem .75rem; border-radius:6px; margin-bottom:.4rem; font-size:.85rem; font-family:monospace; }
  .ok  { background:rgba(16,185,129,.12); color:#6ee7b7; }
  .err { background:rgba(239,68,68,.12);  color:#fca5a5; }
  .result { margin-top:1.5rem; padding:1.1rem; border-radius:10px; text-align:center; }
  .result.success { background:rgba(16,185,129,.15); border:1px solid #10b981; }
  .result.fail    { background:rgba(239,68,68,.15);  border:1px solid #ef4444; }
  .result h2 { font-size:1.1rem; margin-bottom:.5rem; }
  .result p  { font-size:.85rem; color:#94a3b8; }
  .btn { display:inline-block; margin-top:1rem; padding:.65rem 1.4rem; background:#0891b2; color:#fff; border-radius:8px; text-decoration:none; font-weight:700; font-size:.9rem; }
  .warn { background:rgba(245,158,11,.12); color:#fcd34d; padding:.6rem .9rem; border-radius:7px; font-size:.82rem; margin-top:1rem; }
</style>
</head>
<body>
<div class="box">
  <h1>📦 排班管理系統 — 安裝程式</h1>
  <p class="sub">自動建立資料庫 <code>hr_shift_db</code> 及所有資料表</p>

  <?php foreach ($logs as $l): ?>
    <div class="log-item ok"><?= htmlspecialchars($l) ?></div>
  <?php endforeach; ?>
  <?php foreach ($errors as $e): ?>
    <div class="log-item err"><?= htmlspecialchars($e) ?></div>
  <?php endforeach; ?>

  <?php if ($success): ?>
    <div class="result success">
      <h2>🎉 安裝成功！</h2>
      <p>資料庫與所有資料表已建立完成</p>
      <a href="index.php" class="btn">🔓 前往登入頁</a>
    </div>
    <div class="warn">
      ⚠️ 安裝完成後，請透過 FTP 刪除 <strong>setup.php</strong> 以確保安全
    </div>
  <?php else: ?>
    <div class="result fail">
      <h2>❌ 安裝失敗</h2>
      <p>請修正上方紅色錯誤後，重新整理此頁面再試一次</p>
      <p style="margin-top:.5rem;">最常見原因：<strong>setup.php 第 9–10 行的帳號密碼未填正確</strong></p>
    </div>
  <?php endif; ?>
</div>
</body>
</html>
