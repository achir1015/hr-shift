<?php
require_once __DIR__ . '/config.php';
$page_title = '月統計報表';
$active     = 'stats';

$pdo = getDB();
$cid = currentCompanyId();

// ── POST 處理 ─────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'] ?? '';

    // 手動新增/更新月統計
    if ($type === 'save') {
        $emp_id       = (int)$_POST['emp_id'];
        $year_month   = $_POST['year_month'];
        $work_days    = (int)$_POST['total_work_days'];
        $work_hours   = (float)$_POST['total_work_hours'];
        $ot_hours     = (float)$_POST['overtime_hours'];
        $hol_days     = (int)$_POST['holiday_work_days'];
        $est_salary   = (float)$_POST['est_salary'];
        $is_final     = isset($_POST['is_finalized']) ? 1 : 0;

        $st = $pdo->prepare(
            'INSERT INTO Monthly_Stats_Tab
             (emp_id,year_month,total_work_days,total_work_hours,overtime_hours,holiday_work_days,est_salary,is_finalized)
             VALUES(?,?,?,?,?,?,?,?)
             ON DUPLICATE KEY UPDATE
               total_work_days=VALUES(total_work_days),
               total_work_hours=VALUES(total_work_hours),
               overtime_hours=VALUES(overtime_hours),
               holiday_work_days=VALUES(holiday_work_days),
               est_salary=VALUES(est_salary),
               is_finalized=VALUES(is_finalized)'
        );
        $st->execute([$emp_id,$year_month,$work_days,$work_hours,$ot_hours,$hol_days,$est_salary,$is_final]);
        flash('月統計已更新');
        header('Location: stats.php');
        exit;
    }

    // 自動結算（依 Schedule_Detail + Attendance_Tab 計算）
    if ($type === 'auto_calc') {
        $year_month = $_POST['year_month'];
        list($yr, $mo) = explode('-', $year_month);

        // 每個員工計算
        $emp_list = $pdo->prepare('SELECT emp_id,monthly_salary,hourly_wage,work_type FROM Employee_Tab WHERE company_id=?');
        $emp_list->execute([$cid]);
        $emp_list = $emp_list->fetchAll();

        foreach ($emp_list as $emp) {
            $eid = $emp['emp_id'];

            // 上班天數：Schedule_Detail 中有 shift_id 且非休假
            $sdSt = $pdo->prepare(
                'SELECT COUNT(DISTINCT sd.work_date) FROM Schedule_Detail sd
                 JOIN Schedule_Master sm ON sd.schedule_id=sm.schedule_id
                 JOIN Shift_Type_Tab st ON sd.shift_id=st.shift_id
                 WHERE sm.company_id=? AND sd.emp_id=?
                   AND DATE_FORMAT(sd.work_date,"%Y-%m")=?
                   AND st.is_holiday=0'
            );
            $sdSt->execute([$cid, $eid, $year_month]);
            $work_days = (int)$sdSt->fetchColumn();

            // 總工時（從 Shift_Type_Tab 加總 total_hours）
            $hrSt = $pdo->prepare(
                'SELECT COALESCE(SUM(st.total_hours),0) FROM Schedule_Detail sd
                 JOIN Schedule_Master sm ON sd.schedule_id=sm.schedule_id
                 JOIN Shift_Type_Tab st ON sd.shift_id=st.shift_id
                 WHERE sm.company_id=? AND sd.emp_id=?
                   AND DATE_FORMAT(sd.work_date,"%Y-%m")=?
                   AND st.is_holiday=0'
            );
            $hrSt->execute([$cid, $eid, $year_month]);
            $work_hours = (float)$hrSt->fetchColumn();

            // 法定工時（每月）= 工作天數 * 8（簡化）
            $legal_hours  = $work_days * 8;
            $overtime     = max(0, $work_hours - $legal_hours);

            // 假日出勤
            $holSt = $pdo->prepare(
                'SELECT COUNT(DISTINCT sd.work_date) FROM Schedule_Detail sd
                 JOIN Schedule_Master sm ON sd.schedule_id=sm.schedule_id
                 JOIN Shift_Type_Tab st ON sd.shift_id=st.shift_id
                 WHERE sm.company_id=? AND sd.emp_id=?
                   AND DATE_FORMAT(sd.work_date,"%Y-%m")=?
                   AND st.is_holiday=0
                   AND DAYOFWEEK(sd.work_date) IN (1,7)'
            );
            $holSt->execute([$cid, $eid, $year_month]);
            $hol_days = (int)$holSt->fetchColumn();

            // 預估薪資（簡化版）
            if ($emp['monthly_salary']) {
                $base_salary = (float)$emp['monthly_salary'];
                $daily_rate  = $base_salary / 30;
                $ot_rate     = ($base_salary / 240) * 1.33;
                $hol_rate    = $daily_rate * 2;
                $est_salary  = $base_salary + ($overtime * $ot_rate) + ($hol_days * $hol_rate);
            } elseif ($emp['hourly_wage']) {
                $hr = (float)$emp['hourly_wage'];
                $est_salary = ($work_hours * $hr) + ($overtime * $hr * 0.33) + ($hol_days * $hr * 8 * 2);
            } else {
                $est_salary = 0;
            }

            $upd = $pdo->prepare(
                'INSERT INTO Monthly_Stats_Tab
                 (emp_id,year_month,total_work_days,total_work_hours,overtime_hours,holiday_work_days,est_salary,is_finalized)
                 VALUES(?,?,?,?,?,?,?,0)
                 ON DUPLICATE KEY UPDATE
                   total_work_days=VALUES(total_work_days),
                   total_work_hours=VALUES(total_work_hours),
                   overtime_hours=VALUES(overtime_hours),
                   holiday_work_days=VALUES(holiday_work_days),
                   est_salary=VALUES(est_salary)'
            );
            $upd->execute([$eid,$year_month,$work_days,$work_hours,$overtime,$hol_days,$est_salary]);
        }

        flash("已自動結算 $year_month 月份薪資");
        header("Location: stats.php?month=$year_month");
        exit;
    }

    // 確認結算（鎖定）
    if ($type === 'finalize') {
        $year_month = $_POST['year_month'];
        $pdo->prepare(
            'UPDATE Monthly_Stats_Tab ms
             JOIN Employee_Tab e ON ms.emp_id=e.emp_id
             SET ms.is_finalized=1
             WHERE e.company_id=? AND ms.year_month=?'
        )->execute([$cid, $year_month]);
        flash("$year_month 月份結算已鎖定");
        header("Location: stats.php?month=$year_month");
        exit;
    }
}

// ── 讀取 ─────────────────────────────────────────────────────
// ── 月份選擇、員工過濾 ───────────────────────────────────────
$filterMonth = trim($_GET['month'] ?? date('Y-m'));

// 一般員工只看自己
if (!isManager()) {
    $stats = $pdo->prepare(
        'SELECT ms.*, e.real_name, e.work_type, e.monthly_salary, e.hourly_wage
         FROM Monthly_Stats_Tab ms
         JOIN Employee_Tab e ON ms.emp_id=e.emp_id
         WHERE ms.emp_id=? AND ms.year_month=?'
    );
    $stats->execute([currentEmpId(), $filterMonth]);
} else {
    $stats = $pdo->prepare(
        'SELECT ms.*, e.real_name, e.work_type, e.monthly_salary, e.hourly_wage
         FROM Monthly_Stats_Tab ms
         JOIN Employee_Tab e ON ms.emp_id=e.emp_id
         WHERE e.company_id=? AND ms.year_month=?
         ORDER BY e.real_name'
    );
    $stats->execute([$cid, $filterMonth]);
}
$stats = $stats->fetchAll();

// 合計
$totHours  = array_sum(array_column($stats, 'total_work_hours'));
$totSalary = array_sum(array_column($stats, 'est_salary'));
$totDays   = array_sum(array_column($stats, 'total_work_days'));
$isLocked  = !empty($stats) && $stats[0]['is_finalized'];

require_once '_nav.php';
?>

<div class="page-header">
  <div class="page-title">月統計報表<small>工時、加班、預估薪資結算</small></div>
  <div style="display:flex;gap:.5rem;flex-wrap:wrap;">
    <?php if (isManager()): ?>
    <form method="POST" style="display:inline;">
      <input type="hidden" name="type" value="auto_calc">
      <input type="hidden" name="year_month" value="<?= e($filterMonth) ?>">
      <button type="submit" class="btn btn-primary"
        onclick="return confirm('確定對 <?= e($filterMonth) ?> 執行自動結算嗎？')">
        &#x26A1; 自動結算
      </button>
    </form>
    <?php if ($stats && !$isLocked): ?>
      <form method="POST" style="display:inline;">
        <input type="hidden" name="type" value="finalize">
        <input type="hidden" name="year_month" value="<?= e($filterMonth) ?>">
        <button type="submit" class="btn btn-success"
          onclick="return confirm('確定鎖定 <?= e($filterMonth) ?> 月份結算嗎？')">
          &#x1F512; 鎖定結算
        </button>
      </form>
    <?php endif; ?>
    <button class="btn btn-secondary" onclick="openModal('modalAdd')">✏️ 手動輸入</button>
    <?php endif; ?>
  </div>
</div>

<!-- 月份選擇 -->
<form method="GET" class="card mb-2">
  <div class="card-body" style="padding:.8rem 1rem;display:flex;gap:.6rem;align-items:flex-end;flex-wrap:wrap;">
    <div class="form-group" style="margin:0;">
      <label class="form-label">月份</label>
      <input type="month" name="month" class="form-control" value="<?= e($filterMonth) ?>">
    </div>
    <button type="submit" class="btn btn-primary btn-sm">查詢</button>
  </div>
</form>

<!-- 合計卡片 -->
<?php if ($stats): ?>
<div class="stats-grid mb-2">
  <div class="stat-card">
    <div class="stat-icon cyan">👥</div>
    <div>
      <div class="stat-value"><?= count($stats) ?></div>
      <div class="stat-label">統計員工數</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon amber">📅</div>
    <div>
      <div class="stat-value"><?= $totDays ?></div>
      <div class="stat-label">總出勤天數</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon blue">⏱️</div>
    <div>
      <div class="stat-value"><?= number_format($totHours,1) ?>h</div>
      <div class="stat-label">總工時</div>
    </div>
  </div>
  <div class="stat-card">
    <div class="stat-icon green">💰</div>
    <div>
      <div class="stat-value" style="font-size:1.15rem;"><?= number_format($totSalary) ?></div>
      <div class="stat-label">預估總薪資（元）</div>
    </div>
  </div>
  <div class="stat-card" style="border-left:3px solid <?= $isLocked?'var(--success)':'var(--warning)' ?>;">
    <div class="stat-icon <?= $isLocked?'green':'amber' ?>"><?= $isLocked?'🔒':'✏️' ?></div>
    <div>
      <div class="stat-value" style="font-size:1rem;"><?= $isLocked?'已鎖定':'試算中' ?></div>
      <div class="stat-label">結算狀態</div>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- 統計表格 -->
<div class="card">
  <div class="card-header">
    <div class="card-title">📊 <?= e($filterMonth) ?> 月份統計</div>
    <?php if ($isLocked): ?>
      <span class="badge badge-green">🔒 已確認結算</span>
    <?php endif; ?>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>員工</th>
          <th>工時型態</th>
          <th>出勤天數</th>
          <th>總工時</th>
          <th>加班時數</th>
          <th>假日出勤天</th>
          <th>預估薪資</th>
          <th>狀態</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($stats): ?>
          <?php foreach ($stats as $s): ?>
            <tr>
              <td><strong><?= e($s['real_name']) ?></strong></td>
              <td>
                <?php $wbadge = ['正常工時'=>'badge-cyan','變形工時'=>'badge-amber','兼職'=>'badge-green']; ?>
                <span class="badge <?= $wbadge[$s['work_type']] ?? 'badge-gray' ?>"><?= e($s['work_type']) ?></span>
              </td>
              <td style="font-family:'DM Mono',monospace;"><?= $s['total_work_days'] ?> 天</td>
              <td style="font-family:'DM Mono',monospace;font-weight:600;"><?= number_format($s['total_work_hours'],1) ?> h</td>
              <td style="font-family:'DM Mono',monospace;color:<?= $s['overtime_hours']>0?'var(--danger)':'var(--text-muted)' ?>;">
                <?= number_format($s['overtime_hours'],1) ?> h
              </td>
              <td style="font-family:'DM Mono',monospace;"><?= $s['holiday_work_days'] ?> 天</td>
              <td style="font-family:'DM Mono',monospace;font-weight:700;font-size:.95rem;">
                $<?= number_format($s['est_salary']) ?>
              </td>
              <td>
                <?php if ($s['is_finalized']): ?>
                  <span class="badge badge-green">🔒 確認</span>
                <?php else: ?>
                  <span class="badge badge-amber">🧮 試算</span>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
          <!-- 合計列 -->
          <tr style="background:#f8fafc;font-weight:700;">
            <td colspan="2">合計</td>
            <td><?= $totDays ?> 天</td>
            <td><?= number_format($totHours,1) ?> h</td>
            <td>—</td>
            <td>—</td>
            <td style="color:var(--success);">$<?= number_format($totSalary) ?></td>
            <td>—</td>
          </tr>
        <?php else: ?>
          <tr>
            <td colspan="8">
              <div class="empty-state">
                <div class="icon">📊</div>
                <p>本月尚無統計資料，請點「⚡ 自動結算」或手動輸入</p>
              </div>
            </td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal：手動輸入 -->
<div class="modal-overlay" id="modalAdd">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title">✏️ 手動輸入 / 調整統計</div>
      <button class="modal-close" onclick="closeModal('modalAdd')">✕</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="type" value="save">
        <div class="form-grid">
          <div class="form-group full">
            <label class="form-label">員工 <span class="req">*</span></label>
            <select name="emp_id" class="form-control" required>
              <option value="">請選擇</option>
              <?php foreach ($emps as $e): ?>
                <option value="<?= $e['emp_id'] ?>"><?= e($e['real_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group">
            <label class="form-label">年月</label>
            <input type="month" name="year_month" class="form-control" value="<?= e($filterMonth) ?>">
          </div>
          <div class="form-group">
            <label class="form-label">出勤天數</label>
            <input type="number" name="total_work_days" class="form-control" value="0" min="0">
          </div>
          <div class="form-group">
            <label class="form-label">總工時（小時）</label>
            <input type="number" name="total_work_hours" class="form-control" value="0" step="0.5">
          </div>
          <div class="form-group">
            <label class="form-label">加班時數</label>
            <input type="number" name="overtime_hours" class="form-control" value="0" step="0.5">
          </div>
          <div class="form-group">
            <label class="form-label">假日出勤天數</label>
            <input type="number" name="holiday_work_days" class="form-control" value="0">
          </div>
          <div class="form-group">
            <label class="form-label">預估薪資（元）</label>
            <input type="number" name="est_salary" class="form-control" value="0" step="100">
          </div>
          <div class="form-group" style="align-self:flex-end;">
            <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer;">
              <input type="checkbox" name="is_finalized" value="1">
              <span>鎖定（確認結算）</span>
            </label>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('modalAdd')">取消</button>
        <button type="submit" class="btn btn-primary">💾 儲存</button>
      </div>
    </form>
  </div>
</div>

<?php require_once '_footer.php'; ?>
