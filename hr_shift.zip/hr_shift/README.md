# 排班管理系統 — 部署說明

## 📁 目錄結構

```
hr_shift/
├── config.php          ← 資料庫設定（必須先修改）
├── index.php           ← 登入頁
├── logout.php          ← 登出
├── _nav.php            ← 共用側邊欄（include）
├── _footer.php         ← 共用頁尾（include）
├── dashboard.php       ← 儀表板
├── companies.php       ← 公司 / 部門管理
├── employees.php       ← 員工管理
├── shifts.php          ← 班別設定
├── schedule.php        ← 排班管理（核心功能）
├── attendance.php      ← 打卡紀錄
├── availability.php    ← 行事曆同步
├── stats.php           ← 月統計報表
└── assets/
    └── style.css       ← 全站 CSS
```

---

## 🚀 部署步驟

### 1. 上傳檔案
透過 FTP (http://ipmos.ngrok.app/filemanager.php) 將整個 `hr_shift/` 資料夾上傳至網站根目錄。

完成後網址為：`https://ipmos.ngrok.app/hr_shift/`

---

### 2. 建立資料庫
1. 開啟 phpMyAdmin：http://ipmos.ngrok.app/phpMyAdmin/index.php
2. 匯入 `hr_shift_db_schema.sql`（之前已產生的 SQL 檔）
3. 確認資料庫 `hr_shift_db` 已建立，包含所有資料表

---

### 3. 修改 config.php

```php
define('DB_HOST', 'localhost');   // 通常不用改
define('DB_NAME', 'hr_shift_db');
define('DB_USER', 'root');        // 改成伺服器的 MySQL 帳號
define('DB_PASS', '');            // 改成 MySQL 密碼

define('ADMIN_USER', 'admin');    // 管理員帳號（可自訂）
define('ADMIN_PASS', 'admin1234'); // ⚠️ 上線前請務必修改密碼
```

---

### 4. 登入
開啟 `https://ipmos.ngrok.app/hr_shift/`

預設帳號：`admin`
預設密碼：`admin1234`

---

## 📋 使用流程

```
1. 建立公司 → 2. 新增部門 → 3. 設定班別 → 4. 新增員工
    ↓
5. 新建排班表（草稿）→ 6. 填入班別 → 7. 發布
    ↓
8. 員工打卡（Attendance）→ 9. 月底自動結算 → 10. 鎖定確認
```

---

## 💡 功能說明

| 功能 | 說明 |
|------|------|
| 公司/部門管理 | 支援多公司，免統編建立 |
| 員工管理 | 實名制，設定時薪/月薪 |
| 班別設定 | 顏色標記，調班防呆（相同時數才能調） |
| 排班管理 | 格狀排班表，草稿→發布，發布後鎖定 |
| 打卡紀錄 | GPS/WIFI，異常標記管理 |
| 行事曆同步 | 有空/沒空狀態，供排班參考 |
| 月統計報表 | 自動計算工時/加班/薪資，支援鎖定 |

---

## ⚙️ PHP 版本需求
- PHP 7.4+ (建議 8.0+)
- PDO + pdo_mysql 擴充套件
- MySQL 5.7+ 或 MariaDB 10.3+
