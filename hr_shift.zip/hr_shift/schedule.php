<?php
require_once __DIR__ . '/config.php';
$page_title = isManager() ? '排班管理' : '我的排班';
$active     = 'schedule';

$pdo    = getDB();
$cid    = currentCompanyId();
$empId  = currentEmpId();
$action = $_GET['action'] ?? 'list';

// ── POST 處理（僅管理者）────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isManager()) {
    $type = $_POST['type'] ?? '';

    if ($type === 'create_master') {
        $start = $_POST['date_range_start'];
        $end   = $_POST['date_range_end'];
        $st = $pdo->prepare(
            "INSERT INTO Schedule_Master(company_id,date_range_start,date_range_end,status)
             VALUES(?,?,?,'草稿')"
        );
        $st->execute([$cid, $start, $end]);
        $newId = $pdo->lastInsertId();
        flash('排班表已建立（草稿）');
        header("Location: schedule.php?action=edit&id=$newId");
        exit;
    }

    if ($type === 'save_detail') {
        $sid   = (int)$_POST['schedule_id'];
        $cells = $_POST['cells'] ?? array();
        $chk   = $pdo->prepare('SELECT status FROM Schedule_Master WHERE schedule_id=? AND company_id=?');
        $chk->execute([$sid, $cid]);
        $master = $chk->fetch();
        if (!$master || $master['status'] !== '草稿') {
            flash('已發布的班表無法修改', 'error');
            header("Location: schedule.php?action=edit&id=$sid");
            exit;
        }
        foreach ($cells as $eid => $dates) {
            foreach ($dates as $date => $shift_id) {
                $shift_id = $shift_id ?: null;
                $dow = array('日','一','二','三','四','五','六')[date('w', strtotime($date))];
                $st = $pdo->prepare(
                    'INSERT INTO Schedule_Detail(schedule_id,emp_id,work_date,day_of_week,shift_id)
                     VALUES(?,?,?,?,?)
                     ON DUPLICATE KEY UPDATE shift_id=VALUES(shift_id)'
                );
                $st->execute([$sid, $eid, $date, $dow, $shift_id]);
            }
        }
        flash('排班明細已儲存');
        header("Location: schedule.php?action=edit&id=$sid");
        exit;
    }

    if ($type === 'publish') {
        $sid = (int)$_POST['schedule_id'];
        $pdo->prepare(
            "UPDATE Schedule_Master SET status='已發布',published_at=NOW()
             WHERE schedule_id=? AND company_id=?"
        )->execute([$sid, $cid]);
        flash('班表已發布');
        header('Location: schedule.php');
        exit;
    }

    if ($type === 'delete') {
        $sid = (int)$_POST['schedule_id'];
        $pdo->prepare('DELETE FROM Schedule_Master WHERE schedule_id=? AND company_id=?')->execute([$sid,$cid]);
        flash('排班表已刪除', 'error');
        header('Location: schedule.php');
        exit;
    }
}

// ── 班表清單 ─────────────────────────────────────────────────
$masters = $pdo->prepare(
    'SELECT * FROM Schedule_Master WHERE company_id=? ORDER BY date_range_start DESC'
);
$masters->execute([$cid]);
$masters = $masters->fetchAll();

$shifts_all = $pdo->prepare('SELECT * FROM Shift_Type_Tab WHERE company_id=? ORDER BY is_holiday,start_time');
$shifts_all->execute([$cid]);
$shifts_all  = $shifts_all->fetchAll();
$shiftsById  = array_column($shifts_all, null, 'shift_id');

// 員工清單（管理者看全部，一般員工只看自己）
if (isManager()) {
    $emps = $pdo->prepare('SELECT emp_id,real_name,dept_id FROM Employee_Tab WHERE company_id=? ORDER BY dept_id,real_name');
    $emps->execute([$cid]);
} else {
    $emps = $pdo->prepare('SELECT emp_id,real_name,dept_id FROM Employee_Tab WHERE emp_id=?');
    $emps->execute([$empId]);
}
$emps = $emps->fetchAll();

// ── 編輯班表 ─────────────────────────────────────────────────
$editMaster = null;
$dates      = array();
$detailMap  = array();

if ($action === 'edit' && isset($_GET['id'])) {
    $st = $pdo->prepare('SELECT * FROM Schedule_Master WHERE schedule_id=? AND company_id=?');
    $st->execute([(int)$_GET['id'], $cid]);
    $editMaster = $st->fetch();
    if ($editMaster) {
        $cur = new DateTime($editMaster['date_range_start']);
        $end = new DateTime($editMaster['date_range_end']);
        while ($cur <= $end) {
            $dates[] = $cur->format('Y-m-d');
            $cur->modify('+1 day');
        }
        if (isManager()) {
            $det = $pdo->prepare('SELECT emp_id,work_date,shift_id FROM Schedule_Detail WHERE schedule_id=?');
            $det->execute([$editMaster['schedule_id']]);
        } else {
            // 一般員工只看自己的
            $det = $pdo->prepare('SELECT emp_id,work_date,shift_id FROM Schedule_Detail WHERE schedule_id=? AND emp_id=?');
            $det->execute([$editMaster['schedule_id'], $empId]);
        }
        foreach ($det->fetchAll() as $row) {
            $detailMap[$row['emp_id']][$row['work_date']] = $row['shift_id'];
        }
    }
}

require_once '_nav.php';
?>

<div class="page-header">
  <div class="page-title">
    <?= isManager() ? '排班管理' : '我的排班' ?>
    <small><?= isManager() ? '建立班表 → 填入班別 → 發布' : '查看個人排班狀況' ?></small>
  </div>
  <?php if (isManager()): ?>
    <button class="btn btn-primary" onclick="openModal('modalCreate')">📅 新建班表</button>
  <?php endif; ?>
</div>

<!-- 班表列表 -->
<?php if ($action === 'list' || !$editMaster): ?>
<div class="card mb-2">
  <div class="card-header"><div class="card-title">📋 班表總覽</div></div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>班表期間</th><th>天數</th><th>狀態</th><th>發布時間</th>
          <?php if (isManager()): ?><th>操作</th><?php endif; ?>
        </tr>
      </thead>
      <tbody>
        <?php if ($masters): ?>
          <?php foreach ($masters as $m): ?>
            <?php $days = (int)((strtotime($m['date_range_end'])-strtotime($m['date_range_start']))/86400)+1; ?>
            <tr>
              <td><strong><?= e($m['date_range_start']) ?></strong> ~ <strong><?= e($m['date_range_end']) ?></strong></td>
              <td><?= $days ?> 天</td>
              <td>
                <?php if ($m['status']==='已發布'): ?>
                  <span class="badge badge-green">✅ 已發布</span>
                <?php else: ?>
                  <span class="badge badge-amber">✏️ 草稿</span>
                <?php endif; ?>
              </td>
              <td class="text-sm text-muted"><?= $m['published_at'] ? e(substr($m['published_at'],0,10)) : '—' ?></td>
              <?php if (isManager()): ?>
              <td>
                <div class="td-actions">
                  <a href="?action=edit&id=<?= $m['schedule_id'] ?>" class="btn btn-sm btn-primary">📝 編輯</a>
                  <?php if ($m['status']==='草稿'): ?>
                    <form method="POST" style="display:inline;">
                      <input type="hidden" name="type" value="publish">
                      <input type="hidden" name="schedule_id" value="<?= $m['schedule_id'] ?>">
                      <button type="submit" class="btn btn-sm btn-success"
                        onclick="return confirm('確定發布？發布後無法修改。')">🚀 發布</button>
                    </form>
                  <?php endif; ?>
                  <form method="POST" id="dm<?= $m['schedule_id'] ?>">
                    <input type="hidden" name="type" value="delete">
                    <input type="hidden" name="schedule_id" value="<?= $m['schedule_id'] ?>">
                    <button type="button" class="btn btn-sm btn-danger"
                      onclick="confirmDelete('確定刪除此班表嗎？','dm<?= $m['schedule_id'] ?>')">🗑️</button>
                  </form>
                </div>
              </td>
              <?php else: ?>
              <td><a href="?action=edit&id=<?= $m['schedule_id'] ?>" class="btn btn-sm btn-secondary">👁️ 查看</a></td>
              <?php endif; ?>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr><td colspan="5"><div class="empty-state"><div class="icon">📅</div><p>尚無班表</p></div></td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php endif; ?>

<!-- 排班格 -->
<?php if ($editMaster): ?>
<div class="card mb-2" style="border-left:4px solid <?= $editMaster['status']==='已發布'?'var(--success)':'var(--warning)' ?>;">
  <div class="card-body" style="padding:.8rem 1rem;display:flex;align-items:center;gap:1rem;flex-wrap:wrap;">
    <span><strong><?= e($editMaster['date_range_start']) ?> ~ <?= e($editMaster['date_range_end']) ?></strong></span>
    <span class="badge <?= $editMaster['status']==='已發布'?'badge-green':'badge-amber' ?>"><?= e($editMaster['status']) ?></span>
    <?php if (isManager() && $editMaster['status']==='草稿'): ?>
      <form method="POST" style="margin-left:auto;">
        <input type="hidden" name="type" value="publish">
        <input type="hidden" name="schedule_id" value="<?= $editMaster['schedule_id'] ?>">
        <button type="submit" class="btn btn-success"
          onclick="return confirm('確定發布？發布後所有明細將鎖定，無法再修改。')">🚀 發布班表</button>
      </form>
    <?php endif; ?>
    <a href="schedule.php" class="btn btn-secondary btn-sm">← 返回</a>
  </div>
</div>

<div class="card mb-2">
  <div class="card-body" style="padding:.6rem 1rem;display:flex;gap:.6rem;flex-wrap:wrap;align-items:center;">
    <span class="text-sm text-muted">班別色彩：</span>
    <?php foreach ($shifts_all as $s): ?>
      <span style="display:inline-flex;align-items:center;gap:.3rem;font-size:.78rem;">
        <span style="width:14px;height:14px;border-radius:3px;background:<?= e($s['color_code']??'#999') ?>;display:inline-block;"></span>
        <?= e($s['shift_name']) ?> (<?= $s['total_hours'] ?>h)
      </span>
    <?php endforeach; ?>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <div class="card-title">👥 排班格</div>
    <?php if (isManager() && $editMaster['status']==='草稿'): ?>
      <button class="btn btn-primary btn-sm" onclick="saveSchedule()">💾 儲存排班</button>
    <?php endif; ?>
  </div>
  <form method="POST" id="scheduleForm">
    <input type="hidden" name="type" value="save_detail">
    <input type="hidden" name="schedule_id" value="<?= $editMaster['schedule_id'] ?>">
    <div class="schedule-grid">
      <table class="schedule-table">
        <thead>
          <tr>
            <th style="min-width:100px;text-align:left;position:sticky;left:0;background:#f8fafc;z-index:2;">員工</th>
            <?php
              $today = date('Y-m-d');
              foreach ($dates as $d):
                $dow      = array('日','一','二','三','四','五','六')[date('w',strtotime($d))];
                $isToday   = ($d === $today);
                $isWeekend = in_array(date('w',strtotime($d)), array(0,6));
            ?>
              <th class="<?= $isToday?'today-col':'' ?>"
                  style="<?= $isWeekend?'color:#dc2626;':'' ?>">
                <?= substr($d,8) ?><br>
                <span style="font-weight:400;font-size:.65rem;">(<?= $dow ?>)</span>
              </th>
            <?php endforeach; ?>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($emps as $emp): ?>
            <tr>
              <td class="emp-name"><?= e($emp['real_name']) ?></td>
              <?php foreach ($dates as $d): ?>
                <?php
                  $curShiftId = isset($detailMap[$emp['emp_id']][$d]) ? $detailMap[$emp['emp_id']][$d] : null;
                  $curShift   = $curShiftId ? (isset($shiftsById[$curShiftId]) ? $shiftsById[$curShiftId] : null) : null;
                  $isLocked   = ($editMaster['status']==='已發布') || !isManager();
                ?>
                <td>
                  <?php if ($isLocked): ?>
                    <?php if ($curShift): ?>
                      <span class="shift-cell" style="background:<?= e($curShift['color_code']??'#ccc') ?>;color:#fff;">
                        <?= e($curShift['shift_name']) ?>
                      </span>
                    <?php else: ?>
                      <span class="shift-empty">休</span>
                    <?php endif; ?>
                  <?php else: ?>
                    <select name="cells[<?= $emp['emp_id'] ?>][<?= $d ?>]"
                            class="shift-select"
                            style="width:100%;padding:2px;font-size:.7rem;border:1px solid #e2e8f0;border-radius:4px;background:<?= $curShift?e($curShift['color_code']??'#fff'):'#f8fafc' ?>;color:<?= $curShift?'#fff':'#333' ?>;">
                      <option value="">休</option>
                      <?php foreach ($shifts_all as $s): ?>
                        <?php if (!$s['is_holiday']): ?>
                          <option value="<?= $s['shift_id'] ?>"
                                  data-color="<?= e($s['color_code']??'#ccc') ?>"
                                  <?= ($curShiftId==$s['shift_id'])?'selected':'' ?>>
                            <?= e($s['shift_name']) ?>
                          </option>
                        <?php endif; ?>
                      <?php endforeach; ?>
                    </select>
                  <?php endif; ?>
                </td>
              <?php endforeach; ?>
            </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php if (isManager() && $editMaster['status']==='草稿'): ?>
      <div class="card-footer">
        <button type="button" class="btn btn-primary" onclick="saveSchedule()">💾 儲存所有排班</button>
      </div>
    <?php endif; ?>
  </form>
</div>
<script>
document.querySelectorAll('.shift-select').forEach(function(sel) {
  sel.addEventListener('change', function() {
    var opt   = this.options[this.selectedIndex];
    var color = opt.dataset.color || '#f8fafc';
    this.style.background = color;
    this.style.color = color === '#f8fafc' ? '#333' : '#fff';
  });
});
function saveSchedule() { document.getElementById('scheduleForm').submit(); }
</script>
<?php endif; ?>

<?php if (isManager()): ?>
<div class="modal-overlay" id="modalCreate">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title">📅 新建排班表</div>
      <button class="modal-close" onclick="closeModal('modalCreate')">✕</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="type" value="create_master">
        <div class="form-grid">
          <div class="form-group">
            <label class="form-label">開始日期</label>
            <input type="date" name="date_range_start" class="form-control" value="<?= date('Y-m-d') ?>" required>
          </div>
          <div class="form-group">
            <label class="form-label">結束日期</label>
            <input type="date" name="date_range_end" class="form-control" value="<?= date('Y-m-d',strtotime('+13 days')) ?>" required>
          </div>
        </div>
        <div style="display:flex;gap:.4rem;margin-top:.75rem;flex-wrap:wrap;">
          <span class="text-sm text-muted" style="align-self:center;">快速：</span>
          <button type="button" class="btn btn-xs btn-secondary" onclick="setRange(7)">1週</button>
          <button type="button" class="btn btn-xs btn-secondary" onclick="setRange(14)">雙週</button>
          <button type="button" class="btn btn-xs btn-secondary" onclick="setRange(28)">四週</button>
          <button type="button" class="btn btn-xs btn-secondary" onclick="setRange(56)">八週</button>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('modalCreate')">取消</button>
        <button type="submit" class="btn btn-primary">📋 建立草稿</button>
      </div>
    </form>
  </div>
</div>
<script>
function setRange(days) {
  var today = new Date();
  var end   = new Date();
  end.setDate(today.getDate() + days - 1);
  var fmt = function(d) { return d.toISOString().slice(0,10); };
  var modal = document.getElementById('modalCreate');
  modal.querySelector('[name="date_range_start"]').value = fmt(today);
  modal.querySelector('[name="date_range_end"]').value   = fmt(end);
}
</script>
<?php endif; ?>

<?php require_once '_footer.php'; ?>
