<?php
// ── _nav.php：所有頁面 include 此檔 ──────────────────────────
// 使用方式：
//   $page_title = '員工管理';
//   $active     = 'employees';
//   require_once '_nav.php';
// ──────────────────────────────────────────────────────────────
requireLogin(); // config.php 提供，未登入自動跳回 index.php

$flash       = getFlash();
$companyName = $_SESSION['hr_company_name'] ?? '—';
$username    = $_SESSION['hr_username'] ?? 'Admin';
$page_title  = $page_title ?? SYS_NAME;
$active      = $active ?? '';

$nav = [
    ['key' => 'dashboard',    'href' => 'dashboard.php',    'icon' => '🏠', 'label' => '儀表板'],
    ['section' => '基本設定'],
    ['key' => 'companies',    'href' => 'companies.php',    'icon' => '🏢', 'label' => '公司 / 部門'],
    ['key' => 'employees',    'href' => 'employees.php',    'icon' => '👤', 'label' => '員工管理'],
    ['key' => 'shifts',       'href' => 'shifts.php',       'icon' => '⏰', 'label' => '班別設定'],
    ['section' => '排班出勤'],
    ['key' => 'schedule',     'href' => 'schedule.php',     'icon' => '📅', 'label' => '排班管理'],
    ['key' => 'attendance',   'href' => 'attendance.php',   'icon' => '📍', 'label' => '打卡紀錄'],
    ['key' => 'availability', 'href' => 'availability.php', 'icon' => '📆', 'label' => '行事曆同步'],
    ['section' => '報表統計'],
    ['key' => 'stats',        'href' => 'stats.php',        'icon' => '📊', 'label' => '月統計報表'],
    ['section' => '系統'],
    ['key' => 'logout',       'href' => 'logout.php',       'icon' => '🚪', 'label' => '登出'],
];
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title><?= e($page_title) ?> — <?= SYS_NAME ?></title>
  <link rel="stylesheet" href="assets/style.css">
</head>
<body>
<div class="sidebar-overlay" id="sideOverlay" onclick="closeSidebar()"></div>

<div class="layout">
  <!-- ── 側邊欄 ── -->
  <aside class="sidebar" id="sidebar">
    <div class="sidebar-brand">
      <div class="logo">📅</div>
      <div class="brand-text">
        <?= SYS_NAME ?>
        <div class="brand-sub">v<?= SYS_VERSION ?></div>
      </div>
    </div>

    <nav class="sidebar-nav">
      <?php foreach ($nav as $item): ?>
        <?php if (isset($item['section'])): ?>
          <div class="nav-section"><?= e($item['section']) ?></div>
        <?php else: ?>
          <a href="<?= e($item['href']) ?>"
             class="nav-item <?= ($active === $item['key']) ? 'active' : '' ?>">
            <span class="icon"><?= $item['icon'] ?></span>
            <?= e($item['label']) ?>
          </a>
        <?php endif; ?>
      <?php endforeach; ?>
    </nav>

    <div class="sidebar-footer">
      <div class="sidebar-user">
        <div class="avatar"><?= strtoupper(mb_substr($username, 0, 1)) ?></div>
        <div class="user-info">
          <div class="user-name"><?= e($username) ?></div>
          <div class="user-role">管理者</div>
        </div>
      </div>
    </div>
  </aside>

  <!-- ── 主內容 ── -->
  <div class="main">
    <!-- 頂部欄 -->
    <header class="topbar">
      <button class="topbar-toggle" onclick="toggleSidebar()">☰</button>
      <span class="topbar-title"><?= e($page_title) ?></span>
      <div class="topbar-right">
        <span class="topbar-company">🏢 <?= e($companyName) ?></span>
      </div>
    </header>

    <!-- 內容區 -->
    <div class="content">
      <?php if ($flash): ?>
        <div class="flash flash-<?= e($flash['type']) ?>">
          <?= ($flash['type'] === 'success') ? '✅' : '⚠️' ?>
          <?= e($flash['msg']) ?>
        </div>
      <?php endif; ?>
