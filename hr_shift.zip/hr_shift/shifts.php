<?php
require_once __DIR__ . '/config.php';
$page_title = '班別設定';
$active     = 'shifts';
requireManager();

$pdo    = getDB();
$cid    = currentCompanyId();
$action = $_GET['action'] ?? 'list';

// ── POST 處理 ─────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'] ?? '';

    if ($type === 'save') {
        $id         = (int)($_POST['shift_id'] ?? 0);
        $name       = trim($_POST['shift_name']);
        $start      = $_POST['start_time'];
        $end        = $_POST['end_time'];
        $rest       = (int)$_POST['rest_time'];
        $total      = (float)$_POST['total_hours'];
        $color      = trim($_POST['color_code']) ?: null;
        $is_holiday = isset($_POST['is_holiday']) ? 1 : 0;

        if ($id) {
            $st = $pdo->prepare(
                'UPDATE Shift_Type_Tab SET shift_name=?,start_time=?,end_time=?,rest_time=?,
                 total_hours=?,color_code=?,is_holiday=? WHERE shift_id=? AND company_id=?'
            );
            $st->execute([$name,$start,$end,$rest,$total,$color,$is_holiday,$id,$cid]);
            flash('班別已更新');
        } else {
            $st = $pdo->prepare(
                'INSERT INTO Shift_Type_Tab
                 (company_id,shift_name,start_time,end_time,rest_time,total_hours,color_code,is_holiday)
                 VALUES(?,?,?,?,?,?,?,?)'
            );
            $st->execute([$cid,$name,$start,$end,$rest,$total,$color,$is_holiday]);
            flash('班別已新增');
        }
        header('Location: shifts.php');
        exit;
    }

    if ($type === 'delete') {
        $id = (int)$_POST['shift_id'];
        $pdo->prepare('DELETE FROM Shift_Type_Tab WHERE shift_id=? AND company_id=?')->execute([$id,$cid]);
        flash('班別已刪除', 'error');
        header('Location: shifts.php');
        exit;
    }
}

// 讀取所有班別
$shifts = $pdo->prepare(
    'SELECT * FROM Shift_Type_Tab WHERE company_id=? ORDER BY is_holiday, start_time'
);
$shifts->execute([$cid]);
$shifts = $shifts->fetchAll();

// 編輯用
$editShift = null;
if ($action === 'edit' && isset($_GET['id'])) {
    $st = $pdo->prepare('SELECT * FROM Shift_Type_Tab WHERE shift_id=? AND company_id=?');
    $st->execute([(int)$_GET['id'], $cid]);
    $editShift = $st->fetch();
}
$showForm = ($action === 'add' || $editShift);

require_once '_nav.php';
?>

<div class="page-header">
  <div class="page-title">班別設定<small>早班 / 晚班 / 大夜班等班別時數設定</small></div>
  <a href="?action=add" class="btn btn-primary">⏰ 新增班別</a>
</div>

<!-- 班別說明 -->
<div class="card mb-2" style="border-left:4px solid var(--cyan);">
  <div class="card-body" style="padding:.8rem 1rem;display:flex;gap:1rem;align-items:center;flex-wrap:wrap;">
    <span>⚙️</span>
    <span class="text-sm">
      <strong>調班防呆規則：</strong>班別的「總時數」必須相等才能互換調班。
      例如 8 小時的早班只能與另一個 8 小時的班別對調。
    </span>
  </div>
</div>

<!-- 表單 -->
<?php if ($showForm): ?>
<div class="card mb-2">
  <div class="card-header">
    <div class="card-title"><?= $editShift ? '✏️ 編輯班別' : '➕ 新增班別' ?></div>
  </div>
  <div class="card-body">
    <form method="POST">
      <input type="hidden" name="type" value="save">
      <?php if ($editShift): ?>
        <input type="hidden" name="shift_id" value="<?= $editShift['shift_id'] ?>">
      <?php endif; ?>
      <div class="form-grid">
        <div class="form-group">
          <label class="form-label">班別名稱 <span class="req">*</span></label>
          <input type="text" name="shift_name" class="form-control"
                 value="<?= e($editShift['shift_name'] ?? '') ?>" placeholder="早班 / 晚班…" required>
        </div>
        <div class="form-group">
          <label class="form-label">上班時間 <span class="req">*</span></label>
          <input type="time" name="start_time" class="form-control"
                 value="<?= e($editShift['start_time'] ?? '08:00') ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">下班時間 <span class="req">*</span></label>
          <input type="time" name="end_time" class="form-control"
                 value="<?= e($editShift['end_time'] ?? '17:00') ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">休息時間（分鐘）</label>
          <input type="number" name="rest_time" class="form-control"
                 value="<?= e($editShift['rest_time'] ?? 60) ?>" min="0" max="240">
        </div>
        <div class="form-group">
          <label class="form-label">班別總時數 <span class="req">*</span>
            <span class="text-muted" style="font-weight:400">（調班防呆比對用）</span>
          </label>
          <input type="number" name="total_hours" class="form-control" step="0.5"
                 value="<?= e($editShift['total_hours'] ?? 8) ?>" min="0" max="24" required>
        </div>
        <div class="form-group">
          <label class="form-label">顏色標記</label>
          <div style="display:flex;gap:.5rem;align-items:center;">
            <input type="color" name="color_code" class="form-control" style="width:60px;height:38px;padding:2px;"
                   value="<?= e($editShift['color_code'] ?? '#4A90E2') ?>">
            <span class="text-sm text-muted">班表格顯示顏色</span>
          </div>
        </div>
        <div class="form-group" style="align-self:flex-end;">
          <label class="form-label" style="display:flex;align-items:center;gap:.5rem;cursor:pointer;">
            <input type="checkbox" name="is_holiday" value="1"
                   <?= (($editShift['is_holiday'] ?? 0) == 1) ? 'checked' : '' ?>>
            這是休假班別
          </label>
          <div class="text-sm text-muted mt-1">勾選後不計入工時</div>
        </div>
      </div>
      <div class="form-actions mt-2">
        <button type="submit" class="btn btn-primary">💾 儲存</button>
        <a href="shifts.php" class="btn btn-secondary">取消</a>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>

<!-- 班別列表 -->
<div class="card">
  <div class="card-header">
    <div class="card-title">⏰ 班別列表</div>
    <span class="badge badge-cyan"><?= count($shifts) ?> 筆</span>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>班別名稱</th>
          <th>上班時間</th>
          <th>下班時間</th>
          <th>休息（分）</th>
          <th>總時數</th>
          <th>顏色</th>
          <th>類型</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($shifts): ?>
          <?php foreach ($shifts as $s): ?>
            <tr>
              <td class="text-muted"><?= $s['shift_id'] ?></td>
              <td><strong><?= e($s['shift_name']) ?></strong></td>
              <td><?= e(substr($s['start_time'],0,5)) ?></td>
              <td><?= e(substr($s['end_time'],0,5)) ?></td>
              <td><?= $s['rest_time'] ?></td>
              <td>
                <span style="font-family:'DM Mono',monospace;font-weight:700;">
                  <?= $s['total_hours'] ?> h
                </span>
              </td>
              <td>
                <span class="dot" style="background:<?= e($s['color_code'] ?? '#999') ?>;width:16px;height:16px;display:inline-block;border-radius:4px;vertical-align:middle;"></span>
                <span class="text-sm text-muted"><?= e($s['color_code'] ?? '—') ?></span>
              </td>
              <td>
                <?php if ($s['is_holiday']): ?>
                  <span class="badge badge-gray">🏖️ 休假</span>
                <?php else: ?>
                  <span class="badge badge-green">💼 上班</span>
                <?php endif; ?>
              </td>
              <td>
                <div class="td-actions">
                  <a href="?action=edit&id=<?= $s['shift_id'] ?>" class="btn btn-sm btn-secondary">✏️</a>
                  <form method="POST" id="ds<?= $s['shift_id'] ?>">
                    <input type="hidden" name="type" value="delete">
                    <input type="hidden" name="shift_id" value="<?= $s['shift_id'] ?>">
                    <button type="button" class="btn btn-sm btn-danger"
                      onclick="confirmDelete('確定刪除班別「<?= e($s['shift_name']) ?>」嗎？','ds<?= $s['shift_id'] ?>')">🗑️</button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr><td colspan="9">
            <div class="empty-state"><div class="icon">⏰</div><p>尚無班別，<a href="?action=add">立即新增</a></p></div>
          </td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require_once '_footer.php'; ?>
