<?php
require_once __DIR__ . '/config.php';
$page_title = '打卡紀錄';
$active     = 'attendance';

$pdo = getDB();
$cid = currentCompanyId();

// ── POST：新增手動打卡 / 刪除 ────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['type'] ?? '';

    if ($type === 'add') {
        $emp_id  = (int)$_POST['emp_id'];
        $ptime   = $_POST['punch_time'];
        $method  = $_POST['punch_method'];
        $valid   = isset($_POST['location_valid']) ? 1 : 0;
        $abnorm  = isset($_POST['is_abnormal'])    ? 1 : 0;

        $st = $pdo->prepare(
            'INSERT INTO Attendance_Tab(emp_id,punch_time,punch_method,location_valid,is_abnormal)
             VALUES(?,?,?,?,?)'
        );
        $st->execute([$emp_id, $ptime, $method, $valid, $abnorm]);
        flash('打卡紀錄已新增');
        header('Location: attendance.php');
        exit;
    }

    if ($type === 'delete') {
        $id = (int)$_POST['punch_id'];
        $pdo->prepare('DELETE FROM Attendance_Tab WHERE punch_id=?')->execute([$id]);
        flash('已刪除打卡紀錄', 'error');
        header('Location: attendance.php');
        exit;
    }

    if ($type === 'toggle_abnormal') {
        $id  = (int)$_POST['punch_id'];
        $val = (int)$_POST['val'];
        $pdo->prepare('UPDATE Attendance_Tab SET is_abnormal=? WHERE punch_id=?')->execute([$val,$id]);
        flash('異常標記已更新');
        header('Location: attendance.php');
        exit;
    }
}

// ── 篩選條件 ─────────────────────────────────────────────────
$filterEmp     = (int)($_GET['emp_id'] ?? 0);
$filterDate    = trim($_GET['date'] ?? '');
$filterAbnorm  = isset($_GET['abnormal']) ? 1 : 0;
$filterMethod  = trim($_GET['method'] ?? '');

// 員工清單（篩選用）
$emps = $pdo->prepare('SELECT emp_id, real_name FROM Employee_Tab WHERE company_id=? ORDER BY real_name');
$emps->execute([$cid]);
$emps = $emps->fetchAll();

// 分頁
$perPage = 30;
$page    = max(1, (int)($_GET['pg'] ?? 1));
$offset  = ($page - 1) * $perPage;

$where  = ['e.company_id=?'];
$params = [$cid];

if ($filterEmp) {
    $where[]  = 'a.emp_id=?';
    $params[] = $filterEmp;
}
if ($filterDate) {
    $where[]  = 'DATE(a.punch_time)=?';
    $params[] = $filterDate;
}
if ($filterAbnorm) {
    $where[] = 'a.is_abnormal=1';
}
if ($filterMethod) {
    $where[]  = 'a.punch_method=?';
    $params[] = $filterMethod;
}

$whereSQL = 'WHERE ' . implode(' AND ', $where);

// 總筆數
$countSQL = "SELECT COUNT(*) FROM Attendance_Tab a JOIN Employee_Tab e ON a.emp_id=e.emp_id $whereSQL";
$stCount  = $pdo->prepare($countSQL);
$stCount->execute($params);
$total    = $stCount->fetchColumn();
$pages    = (int)ceil($total / $perPage);

// 資料
$dataSQL = "SELECT a.*, e.real_name FROM Attendance_Tab a
            JOIN Employee_Tab e ON a.emp_id=e.emp_id
            $whereSQL
            ORDER BY a.punch_time DESC
            LIMIT $perPage OFFSET $offset";
$stData  = $pdo->prepare($dataSQL);
$stData->execute($params);
$records = $stData->fetchAll();

require_once '_nav.php';

// 組建分頁 URL
function pageUrl($pg) {
    $p = $_GET;
    $p['pg'] = $pg;
    return 'attendance.php?' . http_build_query($p);
}
?>

<div class="page-header">
  <div class="page-title">打卡紀錄<small>GPS / WIFI 出勤打卡紀錄查詢</small></div>
  <button class="btn btn-primary" onclick="openModal('modalAdd')">➕ 手動新增打卡</button>
</div>

<!-- 篩選列 -->
<form method="GET" class="card mb-2">
  <div class="card-body" style="padding:.8rem 1rem;">
    <div style="display:flex;gap:.6rem;flex-wrap:wrap;align-items:flex-end;">
      <div class="form-group" style="margin:0;">
        <label class="form-label">員工</label>
        <select name="emp_id" class="form-control" style="min-width:130px;">
          <option value="">全部員工</option>
          <?php foreach ($emps as $e): ?>
            <option value="<?= $e['emp_id'] ?>" <?= $filterEmp==$e['emp_id']?'selected':'' ?>>
              <?= e($e['real_name']) ?>
            </option>
          <?php endforeach; ?>
        </select>
      </div>
      <div class="form-group" style="margin:0;">
        <label class="form-label">日期</label>
        <input type="date" name="date" class="form-control" value="<?= e($filterDate) ?>">
      </div>
      <div class="form-group" style="margin:0;">
        <label class="form-label">打卡方式</label>
        <select name="method" class="form-control">
          <option value="">全部</option>
          <option value="GPS"  <?= $filterMethod==='GPS' ?'selected':'' ?>>GPS</option>
          <option value="WIFI" <?= $filterMethod==='WIFI'?'selected':'' ?>>WIFI</option>
        </select>
      </div>
      <div class="form-group" style="margin:0;align-self:flex-end;">
        <label style="display:flex;align-items:center;gap:.4rem;cursor:pointer;font-size:.82rem;font-weight:600;color:var(--text-muted);">
          <input type="checkbox" name="abnormal" value="1" <?= $filterAbnorm?'checked':'' ?>>
          僅顯示異常
        </label>
      </div>
      <div style="display:flex;gap:.4rem;align-self:flex-end;">
        <button type="submit" class="btn btn-primary btn-sm">🔍 篩選</button>
        <a href="attendance.php" class="btn btn-secondary btn-sm">清除</a>
      </div>
    </div>
  </div>
</form>

<!-- 打卡清單 -->
<div class="card">
  <div class="card-header">
    <div class="card-title">📍 打卡紀錄</div>
    <span class="badge badge-cyan">共 <?= $total ?> 筆</span>
  </div>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th>#</th>
          <th>員工</th>
          <th>打卡時間</th>
          <th>打卡方式</th>
          <th>範圍內</th>
          <th>異常標記</th>
          <th>操作</th>
        </tr>
      </thead>
      <tbody>
        <?php if ($records): ?>
          <?php foreach ($records as $r): ?>
            <tr>
              <td class="text-muted"><?= $r['punch_id'] ?></td>
              <td><strong><?= e($r['real_name']) ?></strong></td>
              <td style="font-family:'DM Mono',monospace;font-size:.82rem;"><?= e($r['punch_time']) ?></td>
              <td>
                <span class="badge <?= $r['punch_method']==='GPS'?'badge-blue':'badge-cyan' ?>">
                  <?= $r['punch_method'] === 'GPS' ? '📡 GPS' : '📶 WIFI' ?>
                </span>
              </td>
              <td>
                <?php if ($r['location_valid']): ?>
                  <span class="badge badge-green">✅ 正常</span>
                <?php else: ?>
                  <span class="badge badge-red">❌ 範圍外</span>
                <?php endif; ?>
              </td>
              <td>
                <?php if ($r['is_abnormal']): ?>
                  <span class="badge badge-red">⚠️ 異常</span>
                <?php else: ?>
                  <span class="badge badge-gray">—</span>
                <?php endif; ?>
              </td>
              <td>
                <div class="td-actions">
                  <form method="POST" style="display:inline;">
                    <input type="hidden" name="type" value="toggle_abnormal">
                    <input type="hidden" name="punch_id" value="<?= $r['punch_id'] ?>">
                    <input type="hidden" name="val" value="<?= $r['is_abnormal']?0:1 ?>">
                    <button type="submit" class="btn btn-xs <?= $r['is_abnormal']?'btn-secondary':'btn-warning' ?>">
                      <?= $r['is_abnormal']?'✅ 解除異常':'⚠️ 標為異常' ?>
                    </button>
                  </form>
                  <form method="POST" id="dp<?= $r['punch_id'] ?>">
                    <input type="hidden" name="type" value="delete">
                    <input type="hidden" name="punch_id" value="<?= $r['punch_id'] ?>">
                    <button type="button" class="btn btn-xs btn-danger"
                      onclick="confirmDelete('確定刪除此打卡紀錄嗎？','dp<?= $r['punch_id'] ?>')">🗑️</button>
                  </form>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
        <?php else: ?>
          <tr><td colspan="7"><div class="empty-state"><div class="icon">📍</div><p>無符合條件的打卡紀錄</p></div></td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- 分頁 -->
  <?php if ($pages > 1): ?>
    <div class="card-footer">
      <div class="pagination">
        <?php if ($page > 1): ?>
          <a href="<?= pageUrl($page-1) ?>">←</a>
        <?php endif; ?>
        <?php for ($i = max(1,$page-2); $i <= min($pages,$page+2); $i++): ?>
          <?php if ($i === $page): ?>
            <span class="current"><?= $i ?></span>
          <?php else: ?>
            <a href="<?= pageUrl($i) ?>"><?= $i ?></a>
          <?php endif; ?>
        <?php endfor; ?>
        <?php if ($page < $pages): ?>
          <a href="<?= pageUrl($page+1) ?>">→</a>
        <?php endif; ?>
        <span class="text-muted text-sm">共 <?= $pages ?> 頁</span>
      </div>
    </div>
  <?php endif; ?>
</div>

<!-- Modal：手動新增打卡 -->
<div class="modal-overlay" id="modalAdd">
  <div class="modal">
    <div class="modal-header">
      <div class="modal-title">➕ 手動新增打卡</div>
      <button class="modal-close" onclick="closeModal('modalAdd')">✕</button>
    </div>
    <form method="POST">
      <div class="modal-body">
        <input type="hidden" name="type" value="add">
        <div class="form-grid">
          <div class="form-group full">
            <label class="form-label">員工 <span class="req">*</span></label>
            <select name="emp_id" class="form-control" required>
              <option value="">請選擇員工</option>
              <?php foreach ($emps as $e): ?>
                <option value="<?= $e['emp_id'] ?>"><?= e($e['real_name']) ?></option>
              <?php endforeach; ?>
            </select>
          </div>
          <div class="form-group full">
            <label class="form-label">打卡時間 <span class="req">*</span></label>
            <input type="datetime-local" name="punch_time" class="form-control"
                   value="<?= date('Y-m-d\TH:i') ?>" required>
          </div>
          <div class="form-group">
            <label class="form-label">打卡方式</label>
            <select name="punch_method" class="form-control">
              <option value="GPS">GPS</option>
              <option value="WIFI">WIFI</option>
            </select>
          </div>
          <div class="form-group" style="align-self:flex-end;">
            <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer;">
              <input type="checkbox" name="location_valid" value="1" checked>
              <span>位置範圍內</span>
            </label>
            <label style="display:flex;align-items:center;gap:.5rem;cursor:pointer;margin-top:.5rem;">
              <input type="checkbox" name="is_abnormal" value="1">
              <span>標記為異常</span>
            </label>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" onclick="closeModal('modalAdd')">取消</button>
        <button type="submit" class="btn btn-primary">💾 新增</button>
      </div>
    </form>
  </div>
</div>

<?php require_once '_footer.php'; ?>
